import test from 'node:test';
import assert from 'node:assert/strict';
import {
  circleIntersectsRect,
  distToSegmentSquared,
  resolvePlayerMovement,
  hasLineOfSight,
  updateLaserBarriers,
  isElectricTileShocking,
  generateProceduralMaze,
  calculateGameStats,
  getAINavigatorCues,
  TILE_SIZE,
  createExploredGrid,
  updateExploredTiles,
  isEntityVisibleToNavigator,
  closestPointOnSegment,
  getClosestThreat,
  getDiscoveredDatacores,
  createDefaultKillerDrone,
  updateKillerDrone,
} from './rules.ts';
import type { LaserBarrier, SentinelDrone } from './types.ts';

test('circleIntersectsRect detects overlap correctly', () => {
  // Center (10, 10), radius 5. Rect (12, 10, 10, 10)
  assert.equal(circleIntersectsRect(10, 10, 5, 12, 10, 10, 10), true);
  // Far away rect
  assert.equal(circleIntersectsRect(10, 10, 5, 50, 50, 10, 10), false);
});

test('distToSegmentSquared calculates perpendicular distance to line segment', () => {
  // Line from (0, 0) to (10, 0), point at (5, 5) -> dist is 5, squared is 25
  const d2 = distToSegmentSquared(5, 5, 0, 0, 10, 0);
  assert.ok(Math.abs(d2 - 25) < 0.001);

  // Point beyond endpoint at (15, 0) -> closest is (10, 0), dist is 5, squared is 25
  const d2Past = distToSegmentSquared(15, 0, 0, 0, 10, 0);
  assert.ok(Math.abs(d2Past - 25) < 0.001);
});

test('resolvePlayerMovement slides along walls and blocks illegal intrusion', () => {
  // Simple 3x3 grid with walls around perimeter
  const grid = [
    [1, 1, 1],
    [1, 0, 1],
    [1, 1, 1],
  ];
  const startX = 1 * TILE_SIZE + 24;
  const startY = 1 * TILE_SIZE + 24;

  // Move right into wall
  const res = resolvePlayerMovement(
    startX,
    startY,
    1000,
    0,
    0.1,
    grid,
    {}
  );
  assert.ok(res.collided);
  // Ensure player did not penetrate the right wall
  assert.ok(res.x < 2 * TILE_SIZE);
});

test('hasLineOfSight detects walls blocking line of sight', () => {
  const grid = [
    [0, 0, 0],
    [0, 1, 0], // Wall in center
    [0, 0, 0],
  ];
  // Direct line from (24, 72) to (120, 72) intersects wall at (48..96, 48..96)
  const clear = hasLineOfSight(24, 72, 120, 72, grid);
  assert.equal(clear, false);

  // Line within top hallway (row 0) is clear
  const clearHall = hasLineOfSight(24, 24, 120, 24, grid);
  assert.equal(clearHall, true);
});

test('updateLaserBarriers correctly toggles duty cycle and detects player hit', () => {
  const lasers: LaserBarrier[] = [
    {
      id: 'test_laser',
      x1: 0,
      y1: 50,
      x2: 100,
      y2: 50,
      period: 4.0,
      dutyCycle: 0.5, // 0..2s active, 2..4s inactive
      offset: 0,
      isActive: false,
      isHacked: false,
      hackTimer: 0,
    },
  ];

  // At time 1.0s, laser is active
  const resActive = updateLaserBarriers(lasers, 0.016, 1.0, 50, 50, 14);
  assert.equal(resActive.activeLasers.length, 1);
  assert.equal(resActive.hit, true);

  // At time 3.0s, laser is inactive
  const resInactive = updateLaserBarriers(lasers, 0.016, 3.0, 50, 50, 14);
  assert.equal(resInactive.activeLasers.length, 0);
  assert.equal(resInactive.hit, false);

  // If hacked, laser is disabled even during active phase
  lasers[0].isHacked = true;
  lasers[0].hackTimer = 3.0;
  const resHacked = updateLaserBarriers(lasers, 0.016, 1.0, 50, 50, 14);
  assert.equal(resHacked.activeLasers.length, 0);
  assert.equal(resHacked.hit, false);
});

test('isElectricTileShocking returns cycling warning and shock states', () => {
  // Tile at (0, 0)
  const safeState = isElectricTileShocking(0, 0, 1.0);
  assert.equal(safeState.isShocking, false);

  const warnState = isElectricTileShocking(0, 0, 2.8);
  assert.equal(warnState.isWarning, true);
  assert.equal(warnState.isShocking, false);

  const shockState = isElectricTileShocking(0, 0, 4.0);
  assert.equal(shockState.isShocking, true);
});

test('generateProceduralMaze creates a bounded maze with valid start and extraction', () => {
  const maze = generateProceduralMaze(13, 11);
  assert.equal(maze.grid.length, 11);
  assert.equal(maze.grid[0].length, 13);
  // Start position tile must be open
  const startGX = Math.floor(maze.startPos.x / TILE_SIZE);
  const startGY = Math.floor(maze.startPos.y / TILE_SIZE);
  assert.equal(maze.grid[startGY][startGX], 0);

  // Extraction position tile must be extraction zone (6)
  const extGX = Math.floor(maze.extractionPos.x / TILE_SIZE);
  const extGY = Math.floor(maze.extractionPos.y / TILE_SIZE);
  assert.equal(maze.grid[extGY][extGX], 6);
});

test('calculateGameStats computes mastery metrics and stealth ranks', () => {
  const perfectStats = calculateGameStats(1, 'TEST', 60, 0, 2, 2, 5, 1, 3);
  assert.equal(perfectStats.rank, 'S');

  const flawedStats = calculateGameStats(1, 'TEST', 180, 4, 0, 2, 5, 1, 1);
  assert.equal(flawedStats.rank, 'B');
});

test('getAINavigatorCues produces tactical callout when laser is ahead', () => {
  const lasers: LaserBarrier[] = [
    {
      id: 'l1',
      x1: 72,
      y1: 100,
      x2: 120,
      y2: 100,
      period: 4,
      dutyCycle: 0.5,
      offset: 0,
      isActive: true,
      isHacked: false,
      hackTimer: 0,
    },
  ];
  const cues = getAINavigatorCues(
    72,
    90, // right next to laser
    [[0]],
    lasers,
    [],
    { x: 500, y: 500 },
    false,
    1.0
  );
  assert.equal(cues.recommendedDirection, 'HOLD');
  assert.equal(cues.hazardAhead, true);
});

test('createExploredGrid and updateExploredTiles reveal tiles near player', () => {
  const explored = createExploredGrid(5, 5);
  assert.equal(explored[0][0], false);
  assert.equal(explored[2][2], false);

  // Player at center of tile (2, 2) with 70px radius (covers tile 2,2 and adjacent tiles)
  const newlyExplored = updateExploredTiles(2 * TILE_SIZE + 24, 2 * TILE_SIZE + 24, explored, 70);
  assert.ok(newlyExplored > 0);
  assert.equal(explored[2][2], true);
  // Far corner (0,0) or (4,4) should remain unexplored
  assert.equal(explored[0][0], false);
});

test('isEntityVisibleToNavigator respects fog radius, beacons, and waves', () => {
  const playerX = 100;
  const playerY = 100;
  const radarRadius = 150;

  // Point right near player
  assert.equal(
    isEntityVisibleToNavigator(120, 100, playerX, playerY, radarRadius),
    true
  );

  // Point far away in unexplored darkness
  assert.equal(
    isEntityVisibleToNavigator(500, 500, playerX, playerY, radarRadius),
    false
  );

  // Point far away but covered by an active tactical beacon
  assert.equal(
    isEntityVisibleToNavigator(500, 500, playerX, playerY, radarRadius, [{ x: 500, y: 510 }]),
    true
  );

  // When fog is disabled, everything is visible
  assert.equal(
    isEntityVisibleToNavigator(900, 900, playerX, playerY, radarRadius, [], [], false),
    true
  );
});

test('closestPointOnSegment finds projected point on horizontal/vertical segments', () => {
  // Segment from (0, 100) to (200, 100), query point at (50, 60)
  const pt = closestPointOnSegment(50, 60, 0, 100, 200, 100);
  assert.equal(pt.x, 50);
  assert.equal(pt.y, 100);
  assert.equal(Math.round(pt.dist), 40);
});

test('getClosestThreat picks closest active laser or drone', () => {
  const lasers: LaserBarrier[] = [
    {
      id: 'l1',
      x1: 0,
      y1: 100,
      x2: 200,
      y2: 100,
      period: 4,
      dutyCycle: 0.5,
      offset: 0,
      isActive: true,
      isHacked: false,
      hackTimer: 0,
    },
    {
      id: 'l2_hacked',
      x1: 0,
      y1: 50,
      x2: 200,
      y2: 50,
      period: 4,
      dutyCycle: 0.5,
      offset: 0,
      isActive: true,
      isHacked: true, // disabled!
      hackTimer: 3,
    },
  ];

  const drones: SentinelDrone[] = [
    {
      id: 'd1',
      x: 300,
      y: 300,
      vx: 0,
      vy: 0,
      radius: 16,
      speed: 70,
      waypoints: [],
      currentWaypointIdx: 0,
      angle: 0,
      fov: Math.PI / 2,
      visionRange: 160,
      alert: 0,
      state: 'patrol',
      stunTimer: 0,
    },
  ];

  // Player at (50, 80).
  // Distance to laser l1 (y=100) is 20px! (l2 is closer at y=50 but hacked)
  // Distance to drone d1 is ~320px
  const threat = getClosestThreat(50, 80, lasers, drones, 250);
  assert.ok(threat !== null);
  assert.equal(threat?.type, 'laser');
  assert.equal(threat?.id, 'l1');
  assert.equal(threat?.distance, 20);
  assert.equal(threat?.isCritical, true);
});

test('getDiscoveredDatacores returns datacores only when their tile has been explored', () => {
  // 3x3 grid with datacore (tile 5) at (1, 1) and (2, 2)
  const grid = [
    [0, 0, 0],
    [0, 5, 0],
    [0, 0, 5],
  ];
  const explored = [
    [true, true, false],
    [true, true, false], // (1, 1) explored
    [false, false, false], // (2, 2) unexplored
  ];
  const doorStates: Record<string, boolean> = {};

  const discovered = getDiscoveredDatacores(grid, explored, doorStates);
  assert.equal(discovered.length, 1);
  assert.equal(discovered[0].gridX, 1);
  assert.equal(discovered[0].gridY, 1);
  assert.equal(discovered[0].isCollected, false);

  // When (1, 1) is collected:
  grid[1][1] = 0;
  doorStates['datacore_1_1'] = true;
  const afterCollection = getDiscoveredDatacores(grid, explored, doorStates);
  assert.equal(afterCollection.length, 1);
  assert.equal(afterCollection[0].isCollected, true);

  // When (2, 2) is also explored:
  explored[2][2] = true;
  const bothDiscovered = getDiscoveredDatacores(grid, explored, doorStates);
  assert.equal(bothDiscovered.length, 2);
  assert.equal(bothDiscovered.find((d) => d.gridX === 2 && d.gridY === 2)?.isCollected, false);
});

test('createDefaultKillerDrone spawns killer on an open tile and sets initial heading', () => {
  const grid = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1],
    [1, 0, 1, 0, 1],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1],
  ];
  // Avoid spawn at (72, 72)
  const killer = createDefaultKillerDrone(grid, 72, 72);
  assert.ok(killer);
  assert.equal(killer.id, 'apex_killer_rover');
  const gx = Math.floor(killer.x / TILE_SIZE);
  const gy = Math.floor(killer.y / TILE_SIZE);
  assert.notEqual(grid[gy][gx], 1); // Must not be in a wall
  assert.ok(Math.abs(killer.heading.dx) + Math.abs(killer.heading.dy) === 1);
});

test('updateKillerDrone moves non-stop and detects player collision', () => {
  const grid = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1],
  ];
  const killer = createDefaultKillerDrone(grid, 72, 72);
  const startX = killer.x;
  const startY = killer.y;

  // Advance time: should move non-stop
  const res = updateKillerDrone(killer, 0.2, grid, {}, 1000, 1000);
  assert.equal(res.collided, false);
  assert.ok(killer.x !== startX || killer.y !== startY); // Must have moved

  // Test collision when player is within radius
  const hitRes = updateKillerDrone(killer, 0.01, grid, {}, killer.x + 5, killer.y + 5);
  assert.equal(hitRes.collided, true);
});

import { CAMPAIGN_MISSIONS, getNavigatorViewTransform } from './rules.ts';

test('getNavigatorViewTransform computes positive zoom and centered offsets', () => {
  // Test split-screen dimensions on 1080p
  const splitT = getNavigatorViewTransform(960, 1080, 23, 15);
  assert.ok(splitT.zoom > 0);
  assert.ok(splitT.offsetX >= 0);
  assert.ok(splitT.offsetY >= 0);
  assert.equal(splitT.mapW, 23 * TILE_SIZE);
  assert.equal(splitT.mapH, 15 * TILE_SIZE);

  // Test wide monitor dimensions
  const monitorT = getNavigatorViewTransform(1920, 1080, 31, 21);
  assert.ok(monitorT.zoom > 0);
  assert.ok(monitorT.offsetX >= 0);
  assert.ok(monitorT.offsetY >= 0);
});

test('all campaign missions are fully traversable with reachable extraction, keycard, and datacores', () => {
  for (const mission of CAMPAIGN_MISSIONS) {
    const grid = mission.grid;
    const h = grid.length;
    const w = grid[0].length;
    assert.equal(w, mission.width, `Mission ${mission.id} width mismatch`);
    assert.equal(h, mission.height, `Mission ${mission.id} height mismatch`);

    const startGX = Math.floor(mission.startPos.x / TILE_SIZE);
    const startGY = Math.floor(mission.startPos.y / TILE_SIZE);
    assert.notEqual(grid[startGY][startGX], 1, `Mission ${mission.id} start is inside a wall`);

    // BFS to find all reachable non-wall tiles (allowing through doors for end-to-end reachability)
    const visited = Array.from({ length: h }, () => Array(w).fill(false));
    const q = [{ x: startGX, y: startGY }];
    visited[startGY][startGX] = true;
    const dirs = [
      { dx: 0, dy: -1 },
      { dx: 0, dy: 1 },
      { dx: -1, dy: 0 },
      { dx: 1, dy: 0 },
    ];

    let foundExit = false;
    let foundKey = false;
    let datacoresFound = 0;

    while (q.length > 0) {
      const cur = q.shift()!;
      const tile = grid[cur.y][cur.x];
      if (tile === 6) foundExit = true;
      if (tile === 4) foundKey = true;
      if (tile === 5) datacoresFound++;

      for (const d of dirs) {
        const nx = cur.x + d.dx;
        const ny = cur.y + d.dy;
        if (nx >= 0 && nx < w && ny >= 0 && ny < h && !visited[ny][nx]) {
          if (grid[ny][nx] !== 1) {
            visited[ny][nx] = true;
            q.push({ x: nx, y: ny });
          }
        }
      }
    }

    assert.ok(foundExit, `Mission ${mission.id} exit (6) is unreachable from start`);
    assert.ok(foundKey, `Mission ${mission.id} keycard (4) is unreachable from start`);
  }
});
