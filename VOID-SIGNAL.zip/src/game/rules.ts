import type {
  GameRunStats,
  KillerDrone,
  LaserBarrier,
  MissionConfig,
  SentinelDrone,
  SonarWave,
  TacticalBeacon,
} from './types';

export const TILE_SIZE = 48;
export const PLAYER_RADIUS = 14;
export const MAX_SHIELDS = 3;
export const MAX_STAMINA = 100;
export const SPRINT_SPEED = 180;
export const WALK_SPEED = 110;
export const DRONE_SPEED = 70;
export const KILLER_DRONE_SPEED = 80;
export const NAVIGATOR_FOG_BASE_RADIUS = 150; // Base radar reveal radius around Operative
export const NAVIGATOR_FOG_PULSE_RADIUS = 280; // Expanded radar radius during Operative whistle / pulse

// Create 2D boolean grid for explored tiles
export function createExploredGrid(rows: number, cols: number): boolean[][] {
  return Array.from({ length: rows }, () => Array(cols).fill(false));
}

// Reveal tiles within radius of player
export function updateExploredTiles(
  playerX: number,
  playerY: number,
  explored: boolean[][],
  revealRadiusPx: number
): number {
  const rows = explored.length;
  if (rows === 0) return 0;
  const cols = explored[0].length;
  let newlyExplored = 0;

  const minGX = Math.max(0, Math.floor((playerX - revealRadiusPx) / TILE_SIZE));
  const maxGX = Math.min(cols - 1, Math.floor((playerX + revealRadiusPx) / TILE_SIZE));
  const minGY = Math.max(0, Math.floor((playerY - revealRadiusPx) / TILE_SIZE));
  const maxGY = Math.min(rows - 1, Math.floor((playerY + revealRadiusPx) / TILE_SIZE));

  for (let gy = minGY; gy <= maxGY; gy++) {
    for (let gx = minGX; gx <= maxGX; gx++) {
      const tileCenterX = gx * TILE_SIZE + TILE_SIZE / 2;
      const tileCenterY = gy * TILE_SIZE + TILE_SIZE / 2;
      const dist2 = (tileCenterX - playerX) ** 2 + (tileCenterY - playerY) ** 2;
      if (dist2 <= revealRadiusPx * revealRadiusPx) {
        if (!explored[gy][gx]) {
          explored[gy][gx] = true;
          newlyExplored++;
        }
      }
    }
  }

  return newlyExplored;
}

export interface DiscoveredDatacore {
  gridX: number;
  gridY: number;
  worldX: number;
  worldY: number;
  isCollected: boolean;
}

// Track and update discovered datacores as exploredGrid updates or as player explores
export function getDiscoveredDatacores(
  grid: number[][],
  exploredGrid: boolean[][],
  doorStates: Record<string, boolean>
): DiscoveredDatacore[] {
  const discovered: DiscoveredDatacore[] = [];
  const rows = grid.length;
  if (rows === 0) return discovered;
  const cols = grid[0].length;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const tile = grid[r][c];
      const isCollected = Boolean(doorStates[`datacore_${c}_${r}`]);
      // Tile 5 is datacore, or if already collected and recorded in doorStates
      if (tile === 5 || isCollected) {
        // Discovered if tile has been explored in exploredGrid
        const isExplored = exploredGrid?.[r]?.[c] ?? false;
        if (isExplored) {
          discovered.push({
            gridX: c,
            gridY: r,
            worldX: c * TILE_SIZE + TILE_SIZE / 2,
            worldY: r * TILE_SIZE + TILE_SIZE / 2,
            isCollected: isCollected || tile !== 5,
          });
        }
      }
    }
  }

  return discovered;
}

// Check if a point/entity is actively illuminated by Navigator's live sensors
export function isEntityVisibleToNavigator(
  x: number,
  y: number,
  playerX: number,
  playerY: number,
  activeRadarRadius: number,
  beacons: { x: number; y: number }[] = [],
  sonarWaves: { x: number; y: number; radius: number }[] = [],
  fogEnabled: boolean = true
): boolean {
  if (!fogEnabled) return true;

  // Check proximity to Operative
  const distToPlayer2 = (x - playerX) ** 2 + (y - playerY) ** 2;
  if (distToPlayer2 <= activeRadarRadius * activeRadarRadius) {
    return true;
  }

  // Check proximity to active Tactical Beacons (each illuminates 120px)
  for (const b of beacons) {
    const distToBeacon2 = (x - b.x) ** 2 + (y - b.y) ** 2;
    if (distToBeacon2 <= 120 * 120) {
      return true;
    }
  }

  // Check inside active Sonar Wave rings (within ±25px of the wave edge)
  for (const w of sonarWaves) {
    const distToWave = Math.hypot(x - w.x, y - w.y);
    if (distToWave <= w.radius + 30 && distToWave >= Math.max(0, w.radius - 40)) {
      return true;
    }
  }

  return false;
}

// Collision helper: Circle vs Axis-Aligned Bounding Box
export function circleIntersectsRect(
  cx: number,
  cy: number,
  radius: number,
  rx: number,
  ry: number,
  rw: number,
  rh: number
): boolean {
  const closestX = Math.max(rx, Math.min(cx, rx + rw));
  const closestY = Math.max(ry, Math.min(cy, ry + rh));
  const dx = cx - closestX;
  const dy = cy - closestY;
  return dx * dx + dy * dy < radius * radius;
}

// Distance between point and line segment
export function distToSegmentSquared(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
  if (l2 === 0) return (px - x1) * (px - x1) + (py - y1) * (py - y1);
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  const projX = x1 + t * (x2 - x1);
  const projY = y1 + t * (y2 - y1);
  return (px - projX) * (px - projX) + (py - projY) * (py - projY);
}

// Find closest point and distance to a line segment
export function closestPointOnSegment(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): { x: number; y: number; dist: number } {
  const l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
  if (l2 === 0) {
    const d = Math.hypot(px - x1, py - y1);
    return { x: x1, y: y1, dist: d };
  }
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  const projX = x1 + t * (x2 - x1);
  const projY = y1 + t * (y2 - y1);
  const dist = Math.hypot(px - projX, py - projY);
  return { x: projX, y: projY, dist };
}

export interface ClosestThreat {
  type: 'laser' | 'drone' | 'killer';
  id: string;
  name: string;
  x: number;
  y: number;
  distance: number;
  isCritical: boolean; // < 75px
}

// Identify immediate closest active hazard to Operative
export function getClosestThreat(
  playerX: number,
  playerY: number,
  lasers: LaserBarrier[],
  drones: SentinelDrone[],
  maxRange: number = 280,
  killer?: KillerDrone | null
): ClosestThreat | null {
  let closest: ClosestThreat | null = null;
  let minDist = maxRange;

  // 1. Check Killer Drone first (Apex threat with top urgency)
  if (killer) {
    const dist = Math.hypot(killer.x - playerX, killer.y - playerY);
    if (dist < minDist) {
      minDist = dist;
      closest = {
        type: 'killer',
        id: killer.id,
        name: 'APEX KILLER',
        x: killer.x,
        y: killer.y,
        distance: Math.round(dist),
        isCritical: dist < 95,
      };
    }
  }

  // 2. Check active lasers (skip hacked ones)
  for (const laser of lasers) {
    if (laser.isActive && !laser.isHacked) {
      const pt = closestPointOnSegment(playerX, playerY, laser.x1, laser.y1, laser.x2, laser.y2);
      if (pt.dist < minDist) {
        minDist = pt.dist;
        closest = {
          type: 'laser',
          id: laser.id,
          name: 'ACTIVE LASER BARRIER',
          x: pt.x,
          y: pt.y,
          distance: Math.round(pt.dist),
          isCritical: pt.dist < 75,
        };
      }
    }
  }

  // 3. Check sentinel drones (skip stunned ones)
  for (const drone of drones) {
    if (drone.state !== 'stunned') {
      const dist = Math.hypot(drone.x - playerX, drone.y - playerY);
      if (dist < minDist) {
        minDist = dist;
        closest = {
          type: 'drone',
          id: drone.id,
          name: drone.state === 'hunting' ? 'HUNTING SENTINEL' : 'PATROL SENTINEL',
          x: drone.x,
          y: drone.y,
          distance: Math.round(dist),
          isCritical: dist < 85,
        };
      }
    }
  }

  return closest;
}

// Move player with wall sliding
export function resolvePlayerMovement(
  currentX: number,
  currentY: number,
  vx: number,
  vy: number,
  dt: number,
  grid: number[][],
  doorStates: Record<string, boolean>
): { x: number; y: number; collided: boolean } {
  const nextX = currentX + vx * dt;
  const nextY = currentY + vy * dt;
  let finalX = currentX;
  let finalY = currentY;
  let collided = false;

  const rows = grid.length;
  const cols = grid[0].length;

  const checkTileObstacle = (gx: number, gy: number): boolean => {
    if (gx < 0 || gx >= cols || gy < 0 || gy >= rows) return true;
    const tile = grid[gy][gx];
    if (tile === 1) return true; // Wall
    if (tile === 2) {
      // Door: check if locked
      const key = `${gx},${gy}`;
      return !doorStates[key];
    }
    return false;
  };

  // Try moving along X axis
  let canMoveX = true;
  const minGX = Math.floor((nextX - PLAYER_RADIUS) / TILE_SIZE);
  const maxGX = Math.floor((nextX + PLAYER_RADIUS) / TILE_SIZE);
  const curMinGY = Math.floor((currentY - PLAYER_RADIUS) / TILE_SIZE);
  const curMaxGY = Math.floor((currentY + PLAYER_RADIUS) / TILE_SIZE);

  for (let gy = curMinGY; gy <= curMaxGY; gy++) {
    for (let gx = minGX; gx <= maxGX; gx++) {
      if (checkTileObstacle(gx, gy)) {
        if (
          circleIntersectsRect(
            nextX,
            currentY,
            PLAYER_RADIUS,
            gx * TILE_SIZE,
            gy * TILE_SIZE,
            TILE_SIZE,
            TILE_SIZE
          )
        ) {
          canMoveX = false;
          collided = true;
          break;
        }
      }
    }
    if (!canMoveX) break;
  }
  if (canMoveX) {
    finalX = nextX;
  }

  // Try moving along Y axis
  let canMoveY = true;
  const curMinGX = Math.floor((finalX - PLAYER_RADIUS) / TILE_SIZE);
  const curMaxGX = Math.floor((finalX + PLAYER_RADIUS) / TILE_SIZE);
  const minGY = Math.floor((nextY - PLAYER_RADIUS) / TILE_SIZE);
  const maxGY = Math.floor((nextY + PLAYER_RADIUS) / TILE_SIZE);

  for (let gy = minGY; gy <= maxGY; gy++) {
    for (let gx = curMinGX; gx <= curMaxGX; gx++) {
      if (checkTileObstacle(gx, gy)) {
        if (
          circleIntersectsRect(
            finalX,
            nextY,
            PLAYER_RADIUS,
            gx * TILE_SIZE,
            gy * TILE_SIZE,
            TILE_SIZE,
            TILE_SIZE
          )
        ) {
          canMoveY = false;
          collided = true;
          break;
        }
      }
    }
    if (!canMoveY) break;
  }
  if (canMoveY) {
    finalY = nextY;
  }

  return { x: finalX, y: finalY, collided };
}

// Raycast grid for line-of-sight
export function hasLineOfSight(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  grid: number[][]
): boolean {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dist = Math.hypot(dx, dy);
  const steps = Math.ceil(dist / 16);
  if (steps === 0) return true;

  const rows = grid.length;
  const cols = grid[0].length;

  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const cx = x1 + dx * t;
    const cy = y1 + dy * t;
    const gx = Math.floor(cx / TILE_SIZE);
    const gy = Math.floor(cy / TILE_SIZE);
    if (gx < 0 || gx >= cols || gy < 0 || gy >= rows) return false;
    if (grid[gy][gx] === 1) return false; // Wall blocks LOS
  }
  return true;
}

// Check laser barrier active state and player collision
export function updateLaserBarriers(
  lasers: LaserBarrier[],
  dt: number,
  currentTime: number,
  playerX: number,
  playerY: number,
  playerRadius: number
): { hit: boolean; activeLasers: LaserBarrier[] } {
  let hit = false;
  const activeLasers: LaserBarrier[] = [];

  for (const laser of lasers) {
    if (laser.isHacked) {
      laser.hackTimer -= dt;
      if (laser.hackTimer <= 0) {
        laser.isHacked = false;
      }
      continue;
    }

    // Determine on/off cycle
    const cycleTime = (currentTime + laser.offset) % laser.period;
    const isActive = cycleTime < laser.period * laser.dutyCycle;
    laser.isActive = isActive;

    if (isActive) {
      activeLasers.push(laser);
      // Check collision
      const d2 = distToSegmentSquared(
        playerX,
        playerY,
        laser.x1,
        laser.y1,
        laser.x2,
        laser.y2
      );
      if (d2 <= playerRadius * playerRadius) {
        hit = true;
      }
    }
  }

  return { hit, activeLasers };
}

// Check electric hazard tiles (tile === 7)
export function isElectricTileShocking(
  gx: number,
  gy: number,
  currentTime: number
): { isWarning: boolean; isShocking: boolean } {
  // Cycle: 5 seconds total. 0..2.5s safe, 2.5..3.5s warning sparks, 3.5..5.0s active shock
  const period = 5.0;
  const offset = (gx * 31 + gy * 17) % 3; // vary phases across grid
  const t = (currentTime + offset) % period;
  const isWarning = t >= 2.5 && t < 3.5;
  const isShocking = t >= 3.5;
  return { isWarning, isShocking };
}

// Update Sentinel Drones
export function updateSentinelDrones(
  drones: SentinelDrone[],
  dt: number,
  grid: number[][],
  playerX: number,
  playerY: number,
  isPlayerNoisy: boolean
): { detectedPlayer: boolean; droneCollided: boolean } {
  let detectedPlayer = false;
  let droneCollided = false;

  for (const drone of drones) {
    if (drone.state === 'stunned') {
      drone.stunTimer -= dt;
      if (drone.stunTimer <= 0) {
        drone.state = 'patrol';
      }
      continue;
    }

    // Proximity touch collision
    const distToPlayer = Math.hypot(drone.x - playerX, drone.y - playerY);
    if (distToPlayer <= drone.radius + PLAYER_RADIUS) {
      droneCollided = true;
    }

    // Check line of sight and cone
    const angleToPlayer = Math.atan2(playerY - drone.y, playerX - drone.x);
    let angleDiff = Math.abs(angleToPlayer - drone.angle);
    while (angleDiff > Math.PI) angleDiff = Math.abs(angleDiff - 2 * Math.PI);

    const inCone =
      distToPlayer <= drone.visionRange &&
      angleDiff <= drone.fov / 2 &&
      hasLineOfSight(drone.x, drone.y, playerX, playerY, grid);

    // If player made a sound nearby (e.g., whistle or sprint), drone can hear within 180px
    const inAudioRange = isPlayerNoisy && distToPlayer <= 180;

    if (inCone || inAudioRange) {
      drone.alert = Math.min(1, drone.alert + dt * 2.5);
      if (drone.alert >= 0.8) {
        detectedPlayer = true;
        drone.state = 'hunting';
        drone.investigateTarget = { x: playerX, y: playerY };
      }
    } else {
      drone.alert = Math.max(0, drone.alert - dt * 0.4);
      if (drone.alert === 0 && drone.state === 'hunting') {
        drone.state = 'patrol';
      }
    }

    // Movement policy
    let targetX = drone.x;
    let targetY = drone.y;

    if (drone.state === 'hunting' && drone.investigateTarget) {
      targetX = drone.investigateTarget.x;
      targetY = drone.investigateTarget.y;
    } else if (drone.waypoints.length > 0) {
      const wp = drone.waypoints[drone.currentWaypointIdx];
      targetX = wp.x;
      targetY = wp.y;
      if (Math.hypot(wp.x - drone.x, wp.y - drone.y) < 10) {
        drone.currentWaypointIdx =
          (drone.currentWaypointIdx + 1) % drone.waypoints.length;
      }
    }

    // Turn towards target
    const desiredAngle = Math.atan2(targetY - drone.y, targetX - drone.x);
    let diff = desiredAngle - drone.angle;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    drone.angle += Math.sign(diff) * Math.min(Math.abs(diff), dt * 3.5);

    // Advance forward
    const speed = drone.state === 'hunting' ? drone.speed * 1.3 : drone.speed;
    const moveX = Math.cos(drone.angle) * speed * dt;
    const moveY = Math.sin(drone.angle) * speed * dt;

    // Check collision for drone with walls
    const nextDX = drone.x + moveX;
    const nextDY = drone.y + moveY;
    const gx = Math.floor(nextDX / TILE_SIZE);
    const gy = Math.floor(nextDY / TILE_SIZE);

    if (
      gx >= 0 &&
      gx < grid[0].length &&
      gy >= 0 &&
      gy < grid.length &&
      grid[gy][gx] !== 1
    ) {
      drone.x = nextDX;
      drone.y = nextDY;
    }
  }

  return { detectedPlayer, droneCollided };
}

// Creates an Apex Killer Drone positioned in an open sector far from the player
export function createDefaultKillerDrone(
  grid: number[][],
  avoidX?: number,
  avoidY?: number
): KillerDrone {
  const rows = grid.length;
  const cols = rows > 0 ? grid[0].length : 0;
  let bestX = 3 * TILE_SIZE + TILE_SIZE / 2;
  let bestY = 3 * TILE_SIZE + TILE_SIZE / 2;
  let maxDist = -1;

  for (let r = 1; r < rows - 1; r++) {
    for (let c = 1; c < cols - 1; c++) {
      const tile = grid[r][c];
      if (tile !== 1) {
        const cx = (c + 0.5) * TILE_SIZE;
        const cy = (r + 0.5) * TILE_SIZE;
        const d =
          avoidX !== undefined && avoidY !== undefined
            ? Math.hypot(cx - avoidX, cy - avoidY)
            : Math.random() * 500;

        if (d > maxDist) {
          maxDist = d;
          bestX = cx;
          bestY = cy;
        }
      }
    }
  }

  const bestCol = Math.floor(bestX / TILE_SIZE);
  const bestRow = Math.floor(bestY / TILE_SIZE);
  const candidateDirs = [
    { dx: 0, dy: -1 },
    { dx: 0, dy: 1 },
    { dx: 1, dy: 0 },
    { dx: -1, dy: 0 },
  ];

  let initialHeading = { dx: 1, dy: 0 };
  for (const dir of candidateDirs) {
    const nr = bestRow + dir.dy;
    const nc = bestCol + dir.dx;
    if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr][nc] !== 1) {
      initialHeading = dir;
      break;
    }
  }

  return {
    id: 'apex_killer_rover',
    name: 'APEX KILLER',
    x: bestX,
    y: bestY,
    radius: 16,
    speed: KILLER_DRONE_SPEED,
    angle: Math.atan2(initialHeading.dy, initialHeading.dx),
    heading: initialHeading,
    nextTileTarget: {
      x: (bestCol + initialHeading.dx + 0.5) * TILE_SIZE,
      y: (bestRow + initialHeading.dy + 0.5) * TILE_SIZE,
    },
    pulseTimer: 0,
    state: 'roaming',
  };
}

// Update Killer Drone: relentless, non-stop random corridor navigation
export function updateKillerDrone(
  killer: KillerDrone,
  dt: number,
  grid: number[][],
  doorStates: Record<string, boolean>,
  playerX: number,
  playerY: number
): { collided: boolean; distToPlayer: number } {
  const rows = grid.length;
  const cols = rows > 0 ? grid[0].length : 0;
  killer.pulseTimer += dt;

  const toTargetX = killer.nextTileTarget.x - killer.x;
  const toTargetY = killer.nextTileTarget.y - killer.y;
  const distToTarget = Math.hypot(toTargetX, toTargetY);
  const step = killer.speed * dt;

  if (distToTarget <= Math.max(2.5, step)) {
    // Snap to tile center
    killer.x = killer.nextTileTarget.x;
    killer.y = killer.nextTileTarget.y;

    const currentC = Math.floor(killer.x / TILE_SIZE);
    const currentR = Math.floor(killer.y / TILE_SIZE);

    const cardinalDirs = [
      { dx: 0, dy: -1 }, // North
      { dx: 0, dy: 1 },  // South
      { dx: 1, dy: 0 },  // East
      { dx: -1, dy: 0 }, // West
    ];

    const validDirs: { dx: number; dy: number }[] = [];
    for (const dir of cardinalDirs) {
      const nc = currentC + dir.dx;
      const nr = currentR + dir.dy;
      if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
        const tileVal = grid[nr][nc];
        const isWall = tileVal === 1;
        const isClosedDoor = tileVal === 4 && !doorStates[`door_${nr}_${nc}`];
        if (!isWall && !isClosedDoor) {
          validDirs.push(dir);
        }
      }
    }

    // Filter out immediate reverse unless in a dead end (keeps it moving non-stop forward)
    const forwardAndTurns = validDirs.filter(
      (d) => !(d.dx === -killer.heading.dx && d.dy === -killer.heading.dy)
    );

    let chosenDir = killer.heading;
    if (forwardAndTurns.length > 0) {
      chosenDir = forwardAndTurns[Math.floor(Math.random() * forwardAndTurns.length)];
    } else if (validDirs.length > 0) {
      chosenDir = validDirs[0];
    }

    killer.heading = chosenDir;
    killer.nextTileTarget = {
      x: (currentC + chosenDir.dx + 0.5) * TILE_SIZE,
      y: (currentR + chosenDir.dy + 0.5) * TILE_SIZE,
    };
  } else {
    // Keep moving non-stop
    const dirX = toTargetX / distToTarget;
    const dirY = toTargetY / distToTarget;
    killer.x += dirX * step;
    killer.y += dirY * step;
  }

  // Smooth turn towards current heading
  const targetAngle = Math.atan2(killer.heading.dy, killer.heading.dx);
  let angleDiff = targetAngle - killer.angle;
  while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
  while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
  killer.angle += Math.sign(angleDiff) * Math.min(Math.abs(angleDiff), dt * 6.0);

  // Proximity collision with player
  const distToPlayer = Math.hypot(killer.x - playerX, killer.y - playerY);
  const collided = distToPlayer <= killer.radius + PLAYER_RADIUS;

  return { collided, distToPlayer };
}

// Procedural Maze Generator (DFS backtracker with loop carving)
export function generateProceduralMaze(
  cols: number,
  rows: number,
  loopiness: number = 0.15
): {
  grid: number[][];
  startPos: { x: number; y: number };
  extractionPos: { x: number; y: number };
  keycardPos: { x: number; y: number };
  terminalPos: { x: number; y: number };
} {
  // Ensure odd dimensions for proper maze walls
  const width = cols % 2 === 0 ? cols + 1 : cols;
  const height = rows % 2 === 0 ? rows + 1 : rows;

  const grid: number[][] = Array.from({ length: height }, () =>
    Array(width).fill(1)
  );

  const stack: [number, number][] = [];
  const startX = 1;
  const startY = 1;
  grid[startY][startX] = 0;
  stack.push([startX, startY]);

  const directions = [
    [0, -2],
    [0, 2],
    [-2, 0],
    [2, 0],
  ];

  while (stack.length > 0) {
    const [cx, cy] = stack[stack.length - 1];
    // Find unvisited neighbors
    const neighbors: [number, number, number, number][] = [];
    for (const [dx, dy] of directions) {
      const nx = cx + dx;
      const ny = cy + dy;
      if (
        nx > 0 &&
        nx < width - 1 &&
        ny > 0 &&
        ny < height - 1 &&
        grid[ny][nx] === 1
      ) {
        neighbors.push([nx, ny, cx + dx / 2, cy + dy / 2]);
      }
    }

    if (neighbors.length > 0) {
      const chosen = neighbors[Math.floor(Math.random() * neighbors.length)];
      const [nx, ny, wallX, wallY] = chosen;
      grid[wallY][wallX] = 0;
      grid[ny][nx] = 0;
      stack.push([nx, ny]);
    } else {
      stack.pop();
    }
  }

  // Carve some loops to make tactical navigation richer
  for (let y = 2; y < height - 2; y += 2) {
    for (let x = 2; x < width - 2; x += 2) {
      if (grid[y][x] === 1 && Math.random() < loopiness) {
        grid[y][x] = 0;
      }
    }
  }

  // Find furthest open cell from start for extraction
  let extractionX = width - 2;
  let extractionY = height - 2;
  grid[extractionY][extractionX] = 6; // Extraction zone

  // Place a keycard and a terminal in accessible dead-ends or rooms
  const openCells: { x: number; y: number }[] = [];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      if (
        grid[y][x] === 0 &&
        !(x === startX && y === startY) &&
        !(x === extractionX && y === extractionY)
      ) {
        openCells.push({ x, y });
      }
    }
  }

  const keycardCell =
    openCells[Math.floor(openCells.length * 0.3)] || { x: 3, y: 3 };
  grid[keycardCell.y][keycardCell.x] = 4; // Keycard

  const terminalCell =
    openCells[Math.floor(openCells.length * 0.7)] || { x: 5, y: 5 };
  grid[terminalCell.y][terminalCell.x] = 3; // Terminal

  return {
    grid,
    startPos: { x: startX * TILE_SIZE + 24, y: startY * TILE_SIZE + 24 },
    extractionPos: {
      x: extractionX * TILE_SIZE + 24,
      y: extractionY * TILE_SIZE + 24,
    },
    keycardPos: {
      x: keycardCell.x * TILE_SIZE + 24,
      y: keycardCell.y * TILE_SIZE + 24,
    },
    terminalPos: {
      x: terminalCell.x * TILE_SIZE + 24,
      y: terminalCell.y * TILE_SIZE + 24,
    },
  };
}

// Calculate Mastery Rank and Score
export function calculateGameStats(
  missionId: number,
  missionTitle: string,
  clearTime: number,
  alarmsTriggered: number,
  datacoresCollected: number,
  totalDatacores: number,
  pingsEmitted: number,
  hacksUsed: number,
  shieldsRemaining: number
): GameRunStats {
  let score = 10000;
  score -= Math.round(clearTime * 15);
  score -= alarmsTriggered * 800;
  score += datacoresCollected * 1500;
  score += shieldsRemaining * 500;

  let rank: 'S' | 'A' | 'B' | 'C' = 'C';
  if (alarmsTriggered === 0 && shieldsRemaining === 3 && clearTime < 120) {
    rank = 'S';
  } else if (alarmsTriggered <= 2 && shieldsRemaining >= 2) {
    rank = 'A';
  } else if (shieldsRemaining >= 1) {
    rank = 'B';
  }

  return {
    missionId,
    missionTitle,
    clearTime,
    alarmsTriggered,
    datacoresCollected,
    totalDatacores,
    pingsEmitted,
    hacksUsed,
    shieldsRemaining,
    rank,
  };
}

// AI Navigator advice engine: analyzes hazards in front of player
export function getAINavigatorCues(
  playerX: number,
  playerY: number,
  grid: number[][],
  lasers: LaserBarrier[],
  drones: SentinelDrone[],
  extractionPos: { x: number; y: number },
  hasKeycard: boolean,
  currentTime: number
): {
  adviceText: string;
  recommendedDirection: 'NORTH' | 'SOUTH' | 'EAST' | 'WEST' | 'HOLD';
  beaconTarget?: { x: number; y: number; label: string };
  hazardAhead: boolean;
} {
  // Check if laser is blocking near player (< 80px)
  for (const laser of lasers) {
    if (laser.isActive && !laser.isHacked) {
      const d2 = distToSegmentSquared(
        playerX,
        playerY,
        laser.x1,
        laser.y1,
        laser.x2,
        laser.y2
      );
      if (d2 < 70 * 70) {
        return {
          adviceText: 'HOLD! Active laser barrier directly ahead. Wait for cycle.',
          recommendedDirection: 'HOLD',
          hazardAhead: true,
        };
      }
    }
  }

  // Check if drone is approaching
  for (const drone of drones) {
    const d = Math.hypot(drone.x - playerX, drone.y - playerY);
    if (d < 140) {
      return {
        adviceText: `WARNING! Drone patrol closing in from ${drone.x > playerX ? 'EAST' : 'WEST'}. Stay quiet!`,
        recommendedDirection: 'HOLD',
        hazardAhead: true,
      };
    }
  }

  // Simple heuristic vector towards extraction or target
  const targetX = extractionPos.x;
  const targetY = extractionPos.y;
  const dx = targetX - playerX;
  const dy = targetY - playerY;

  let dir: 'NORTH' | 'SOUTH' | 'EAST' | 'WEST' = 'EAST';
  if (Math.abs(dx) > Math.abs(dy)) {
    dir = dx > 0 ? 'EAST' : 'WEST';
  } else {
    dir = dy > 0 ? 'SOUTH' : 'NORTH';
  }

  return {
    adviceText: `Path clear. Advance ${dir} towards extraction beacon.`,
    recommendedDirection: dir,
    hazardAhead: false,
    beaconTarget: { x: targetX, y: targetY, label: 'EXTRACTION' },
  };
}

export interface NavigatorTransform {
  zoom: number;
  offsetX: number;
  offsetY: number;
  mapW: number;
  mapH: number;
}

// Calculate optimal tactical blueprint zoom & centered offset for fullscreen / monitor mode
export function getNavigatorViewTransform(
  canvasWidth: number,
  canvasHeight: number,
  missionWidth: number,
  missionHeight: number
): NavigatorTransform {
  const mapW = missionWidth * TILE_SIZE;
  const mapH = missionHeight * TILE_SIZE;

  // Responsive padding for HUD overlays (top ~76px, bottom ~84px, horizontal ~28-48px)
  const paddingX = Math.min(48, Math.max(20, Math.floor(canvasWidth * 0.03)));
  const paddingTop = 76;
  const paddingBottom = 84;

  const availW = Math.max(160, canvasWidth - paddingX * 2);
  const availH = Math.max(160, canvasHeight - (paddingTop + paddingBottom));

  const scaleX = availW / mapW;
  const scaleY = availH / mapH;
  const fitScale = Math.min(scaleX, scaleY);

  // Allow zoom between 0.35 and 1.35 to cleanly fill the screen without extreme pixelation
  const zoom = Math.max(0.35, Math.min(1.35, fitScale));

  const scaledMapW = mapW * zoom;
  const scaledMapH = mapH * zoom;

  // Center horizontally and vertically within available HUD area
  const offsetX = Math.floor((canvasWidth - scaledMapW) / 2);
  const offsetY = Math.floor(paddingTop + (availH - scaledMapH) / 2);

  return { zoom, offsetX, offsetY, mapW, mapH };
}

// 5 Handcrafted high-atmosphere campaign missions with expanded labyrinth complexity
export const CAMPAIGN_MISSIONS: MissionConfig[] = [
  {
    id: 1,
    title: 'OPERATION ZERO-DARK',
    subtitle: 'Initiation & Acoustic Sync',
    description:
      'Infiltrate the extensive perimeter labyrinth (23x15). The Navigator guides the Operative past security blast doors to secure the encryption keycard in the North Vault and extract.',
    threatLevel: 'DEFCON 3 // MODERATE',
    objectives: [
      'Navigate the extensive perimeter corridor complex (23x15)',
      'Locate and secure the Gold Keycard in the North Vault',
      'Unlock pneumatic security blast doors',
      'Evade the relentless Apex Killer Rover and extract safely',
    ],
    hazards: [
      {
        name: 'Reinforced Blast Doors',
        severity: 'LOW',
        icon: 'door',
        description: 'Heavy pneumatic security bulkheads. Keycard is required to disengage locks.',
      },
      {
        name: 'Pitch Blackness',
        severity: 'MEDIUM',
        icon: 'laser',
        description: 'Zero ambient illumination. Runner relies strictly on acoustic sonar echoes.',
      },
      {
        name: 'Apex Killer Rover',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Autonomous rogue stalker drone roaming the facility corridors non-stop at random. Lethal contact.',
      },
    ],
    intelTip:
      'The Navigator must establish clear compass callouts ("North", "East") before the Operative moves into intersections.',
    width: 23,
    height: 15,
    startPos: { x: 72, y: 72 },
    extractionPos: { x: 21 * 48 + 24, y: 13 * 48 + 24 },
    hackCharges: 3,
    grid: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 4, 1],
      [1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 5, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 3, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 3, 0, 0, 1],
      [1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 0, 5, 0, 0, 1, 0, 1, 0, 0, 0, 0, 2, 1, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 6, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ],
    lasers: [],
    drones: [],
  },
  {
    id: 2,
    title: 'LASER GRIDLOCK',
    subtitle: 'Synchronized Timing',
    description:
      'Sector B (25x17) is locked by oscillating high-intensity security beams and roaming threats. The Navigator must count the rhythm and call the window for the blind Operative to cross.',
    threatLevel: 'DEFCON 2 // HIGH RISK',
    objectives: [
      'Synchronize crossing windows through 5 pulsing laser gates',
      'Use Navigator EMP Jam to disable emergency tripwires',
      'Retrieve 3 encrypted datacores across the expanded facility',
      'Evacuate through the security gate while dodging the Apex Killer',
    ],
    hazards: [
      {
        name: 'Oscillating Red Laser Barriers',
        severity: 'HIGH',
        icon: 'laser',
        description: 'Cycling lethal laser tripwires (3.4s - 4.2s periods). Instant shield damage on contact.',
      },
      {
        name: 'Divided Hallway Chokepoints',
        severity: 'MEDIUM',
        icon: 'door',
        description: 'Tight single-tile bottlenecks directly flanked by active energy barriers.',
      },
      {
        name: 'Apex Killer Rover',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Autonomous rogue stalker drone roaming the facility corridors non-stop at random. Lethal contact.',
      },
    ],
    intelTip:
      'The Navigator can count the cadence aloud: "3... 2... 1... SPRINT NOW!" Use the EMP Jam (Key 3 / Click) if the runner is trapped.',
    width: 25,
    height: 17,
    startPos: { x: 72, y: 72 },
    extractionPos: { x: 23 * 48 + 24, y: 15 * 48 + 24 },
    hackCharges: 5,
    grid: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 1],
      [1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 1, 5, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 5, 1, 0, 1, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 0, 3, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 2, 0, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ],
    lasers: [
      {
        id: 'l1',
        x1: 48 * 1,
        y1: 48 * 5.5,
        x2: 48 * 5,
        y2: 48 * 5.5,
        period: 3.8,
        dutyCycle: 0.5,
        offset: 0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l2',
        x1: 48 * 9.5,
        y1: 48 * 1,
        x2: 48 * 9.5,
        y2: 48 * 5,
        period: 3.4,
        dutyCycle: 0.55,
        offset: 1.0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l3',
        x1: 48 * 13,
        y1: 48 * 7.5,
        x2: 48 * 17,
        y2: 48 * 7.5,
        period: 4.2,
        dutyCycle: 0.5,
        offset: 1.8,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l4',
        x1: 48 * 7.5,
        y1: 48 * 11,
        x2: 48 * 7.5,
        y2: 48 * 15,
        period: 3.6,
        dutyCycle: 0.6,
        offset: 0.5,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l5',
        x1: 48 * 17,
        y1: 48 * 13.5,
        x2: 48 * 23,
        y2: 48 * 13.5,
        period: 4.0,
        dutyCycle: 0.55,
        offset: 2.2,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
    ],
    drones: [],
  },
  {
    id: 3,
    title: 'WHISPER PROTOCOL',
    subtitle: 'Autonomous Sentinel Hunt',
    description:
      'Autonomous hunter drones sweep the expansive 27x17 dark research corridors. They respond to footsteps and noisy sprints. The Operative must sneak while the Navigator routes safe paths.',
    threatLevel: 'DEFCON 2 // SEVERE PATROL',
    objectives: [
      'Evade 3 autonomous Sentinel Drones sweeping the northern, central, and southern wings',
      'Maintain acoustic silence (avoid unnecessary sprinting/whistling near drones)',
      'Secure Keycard in the deep eastern junction',
      'Escape to extraction zone unseen',
    ],
    hazards: [
      {
        name: 'Autonomous Hunter Drones',
        severity: 'HIGH',
        icon: 'drone',
        description: 'AI patrol drones with 160px vision cones. Rapidly investigate running footsteps and loud whistles.',
      },
      {
        name: 'Transverse Laser Barrier',
        severity: 'MEDIUM',
        icon: 'laser',
        description: 'Central sector corridor divider laser.',
      },
      {
        name: 'Apex Killer Rover',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Autonomous rogue stalker drone roaming the facility corridors non-stop at random. Lethal contact.',
      },
    ],
    intelTip:
      'Walking is silent; sprinting [Shift] or whistling [E] alerts nearby hunter drones within 180px. Sneak when Navigator advises!',
    width: 27,
    height: 17,
    startPos: { x: 72, y: 72 },
    extractionPos: { x: 25 * 48 + 24, y: 15 * 48 + 24 },
    hackCharges: 5,
    grid: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 4, 1],
      [1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 1, 0, 1, 5, 1, 0, 1, 0, 1, 0, 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 5, 1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 0, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 1, 0, 0, 3, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 5, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 6, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ],
    lasers: [
      {
        id: 'l1',
        x1: 48 * 13.5,
        y1: 48 * 3,
        x2: 48 * 13.5,
        y2: 48 * 6,
        period: 4.0,
        dutyCycle: 0.5,
        offset: 0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l2',
        x1: 48 * 17,
        y1: 48 * 11.5,
        x2: 48 * 22,
        y2: 48 * 11.5,
        period: 3.5,
        dutyCycle: 0.55,
        offset: 1.5,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
    ],
    drones: [
      {
        id: 'd1',
        x: 48 * 5.5,
        y: 48 * 1.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED,
        waypoints: [
          { x: 48 * 5.5, y: 48 * 1.5 },
          { x: 48 * 13.5, y: 48 * 1.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.5,
        visionRange: 160,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
      {
        id: 'd2',
        x: 48 * 13.5,
        y: 48 * 7.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.15,
        waypoints: [
          { x: 48 * 13.5, y: 48 * 7.5 },
          { x: 48 * 21.5, y: 48 * 7.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.5,
        visionRange: 160,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
      {
        id: 'd3',
        x: 48 * 3.5,
        y: 48 * 13.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.1,
        waypoints: [
          { x: 48 * 3.5, y: 48 * 13.5 },
          { x: 48 * 11.5, y: 48 * 13.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.5,
        visionRange: 160,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
    ],
  },
  {
    id: 4,
    title: 'LIGHTNING CORRIDOR',
    subtitle: 'Pulsing Floor Grids & Overrides',
    description:
      'Massive 27x19 high-voltage facility. High-voltage flooring charges on cyclical timers. Physical hacking required by Operative while Navigator provides EMP jams.',
    threatLevel: 'DEFCON 1 // EXTREME HAZARD',
    objectives: [
      'Cross pulsating high-voltage electrified floor sectors in the 27x19 complex',
      'Watch for 1-second pre-shock warning sparks',
      'Bypass dual high-speed sentinel drones in central junctions',
      'Extract before power grid destabilizes',
    ],
    hazards: [
      {
        name: 'High-Voltage Electric Flooring',
        severity: 'CRITICAL',
        icon: 'electric',
        description: 'Cyclical floor surge tiles. Flashes yellow warning sparks for 1.0s before discharging fatal voltage.',
      },
      {
        name: 'Fast Sentinel Drones',
        severity: 'HIGH',
        icon: 'drone',
        description: 'High-speed interceptor drones sweeping the central and southern corridors.',
      },
      {
        name: 'Oscillating Laser Gates',
        severity: 'MEDIUM',
        icon: 'laser',
        description: 'High frequency perimeter barriers.',
      },
      {
        name: 'Apex Killer Rover',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Autonomous rogue stalker drone roaming the facility corridors non-stop at random. Lethal contact.',
      },
    ],
    intelTip:
      'Yellow floor sparks indicate the electric tiles will zap in 1 second. Operative must hold position or sprint across before shock phase!',
    width: 27,
    height: 19,
    startPos: { x: 72, y: 72 },
    extractionPos: { x: 25 * 48 + 24, y: 17 * 48 + 24 },
    hackCharges: 6,
    grid: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 5, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 7, 7, 7, 1, 0, 1, 0, 1, 0, 0, 2, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 7, 7, 0, 0, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 1, 5, 0, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 6, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ],
    lasers: [
      {
        id: 'l1',
        x1: 48 * 1,
        y1: 48 * 9.5,
        x2: 48 * 6,
        y2: 48 * 9.5,
        period: 3.5,
        dutyCycle: 0.5,
        offset: 0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l2',
        x1: 48 * 19.5,
        y1: 48 * 7,
        x2: 48 * 19.5,
        y2: 48 * 12,
        period: 4.2,
        dutyCycle: 0.55,
        offset: 1.8,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
    ],
    drones: [
      {
        id: 'd1',
        x: 48 * 7.5,
        y: 48 * 5.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.25,
        waypoints: [
          { x: 48 * 7.5, y: 48 * 5.5 },
          { x: 48 * 15.5, y: 48 * 5.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.2,
        visionRange: 170,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
      {
        id: 'd2',
        x: 48 * 11.5,
        y: 48 * 13.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.15,
        waypoints: [
          { x: 48 * 11.5, y: 48 * 13.5 },
          { x: 48 * 21.5, y: 48 * 13.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.2,
        visionRange: 170,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
    ],
  },
  {
    id: 5,
    title: 'THE BLACKOUT PROTOCOL',
    subtitle: 'Master Cooperative Heist',
    description:
      'The deepest facility layer (31x21). Massive multi-tier subterranean facility with high-density lasers, 3 hunter drones, and sealed datacore vaults. Total acoustic coordination is required to escape.',
    threatLevel: 'DEFCON 1 // MAXIMUM SECURITY',
    objectives: [
      'Infiltrate the massive maximum security vault complex (31x21)',
      'Bypass triple hunter drone search cones across 3 distinct sectors',
      'Time crossings through 4 high-density laser barriers and electric cores',
      'Recover all 4 classified Datacores and Keycard',
      'Escape through the fortified extraction hangar while evading the Apex Killer',
    ],
    hazards: [
      {
        name: 'Triple Sentinel Interceptors',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Three synchronized hunter drones covering North vault, Central spine, and South perimeter.',
      },
      {
        name: 'Quad Oscillating Lasers',
        severity: 'HIGH',
        icon: 'laser',
        description: 'Multi-frequency laser tripwire barriers guarding entry and extraction routes.',
      },
      {
        name: 'High-Voltage Grid Core',
        severity: 'HIGH',
        icon: 'electric',
        description: 'Electrified central junction.',
      },
      {
        name: 'Apex Killer Rover',
        severity: 'CRITICAL',
        icon: 'drone',
        description: 'Autonomous rogue stalker drone roaming the facility corridors non-stop at random. Lethal contact.',
      },
    ],
    intelTip:
      'Coordinate every move. Use Beacon 2 to mark waypoints in advance, and save EMP Hacks for emergency drone stuns!',
    width: 31,
    height: 21,
    startPos: { x: 72, y: 72 },
    extractionPos: { x: 29 * 48 + 24, y: 19 * 48 + 24 },
    hackCharges: 8,
    grid: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 1],
      [1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1],
      [1, 0, 0, 0, 1, 0, 0, 5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 2, 1, 0, 0, 0, 1, 5, 0, 0, 1, 0, 0, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1],
      [1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 5, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 5, 1, 2, 0, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 0, 3, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 6, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ],
    lasers: [
      {
        id: 'l1',
        x1: 48 * 1,
        y1: 48 * 7.5,
        x2: 48 * 6,
        y2: 48 * 7.5,
        period: 3.2,
        dutyCycle: 0.5,
        offset: 0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l2',
        x1: 48 * 15.5,
        y1: 48 * 1,
        x2: 48 * 15.5,
        y2: 48 * 4,
        period: 3.8,
        dutyCycle: 0.55,
        offset: 1.0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l3',
        x1: 48 * 23,
        y1: 48 * 7.5,
        x2: 48 * 29,
        y2: 48 * 7.5,
        period: 4.0,
        dutyCycle: 0.5,
        offset: 2.0,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
      {
        id: 'l4',
        x1: 48 * 7.5,
        y1: 48 * 13,
        x2: 48 * 7.5,
        y2: 48 * 18,
        period: 3.6,
        dutyCycle: 0.6,
        offset: 0.8,
        isActive: true,
        isHacked: false,
        hackTimer: 0,
      },
    ],
    drones: [
      {
        id: 'd1',
        x: 48 * 5.5,
        y: 48 * 3.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.2,
        waypoints: [
          { x: 48 * 5.5, y: 48 * 3.5 },
          { x: 48 * 15.5, y: 48 * 3.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.2,
        visionRange: 175,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
      {
        id: 'd2',
        x: 48 * 11.5,
        y: 48 * 11.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.25,
        waypoints: [
          { x: 48 * 11.5, y: 48 * 11.5 },
          { x: 48 * 21.5, y: 48 * 11.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.2,
        visionRange: 175,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
      {
        id: 'd3',
        x: 48 * 17.5,
        y: 48 * 17.5,
        vx: 0,
        vy: 0,
        radius: 16,
        speed: DRONE_SPEED * 1.15,
        waypoints: [
          { x: 48 * 17.5, y: 48 * 17.5 },
          { x: 48 * 27.5, y: 48 * 17.5 },
        ],
        currentWaypointIdx: 0,
        angle: 0,
        fov: Math.PI / 2.2,
        visionRange: 160,
        alert: 0,
        state: 'patrol',
        stunTimer: 0,
      },
    ],
  },
];
