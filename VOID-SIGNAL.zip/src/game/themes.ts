export type ColorThemeId = 'cyber_neon' | 'synthwave' | 'emerald_matrix' | 'solar_amber';

export interface ThemeColors {
  id: ColorThemeId;
  name: string;
  tagline: string;
  badge: string;
  // Canvas Colors
  navBg: string;
  navGrid: string;
  navWallFill: string;
  navWallStroke: string;
  navHatch: string;
  operBg: string;
  operWallEcho: string;
  operSonarBase: string;
  primaryAccent: string;
  secondaryAccent: string;
  highlightAccent: string;
  threatRing: string;
  threatGlow: string;
  radarLine: string;
  radarSweep: string;
  beaconGlow: string;
  datacoreGlow: string;
  extractionGlow: string;
  // UI Tailwind Palette Classes
  uiThemeClass: string;
  headerAccentText: string;
  headerBorder: string;
  cardBg: string;
  cardBorder: string;
  primaryBtn: string;
  primaryBtnHover: string;
  glowShadow: string;
  accentPill: string;
}

export const COLOR_THEMES: Record<ColorThemeId, ThemeColors> = {
  cyber_neon: {
    id: 'cyber_neon',
    name: 'Cyberpunk Neon',
    tagline: 'Vibrant Cyan & Ultraviolet Overdrive',
    badge: 'CYBERPUNK',
    navBg: '#050b1a',
    navGrid: 'rgba(0, 240, 255, 0.08)',
    navWallFill: '#0a172e',
    navWallStroke: '#00f0ff',
    navHatch: 'rgba(0, 240, 255, 0.12)',
    operBg: '#020308',
    operWallEcho: 'rgba(0, 240, 255, 0.35)',
    operSonarBase: '#00f0ff',
    primaryAccent: '#00f0ff',
    secondaryAccent: '#f43f5e',
    highlightAccent: '#00ffc8',
    threatRing: '#ff0055',
    threatGlow: '#ff0055',
    radarLine: 'rgba(0, 240, 255, 0.55)',
    radarSweep: 'rgba(0, 255, 204, 0.4)',
    beaconGlow: '#00f0ff',
    datacoreGlow: '#00ffc8',
    extractionGlow: '#00ff88',
    uiThemeClass: 'theme-cyber',
    headerAccentText: 'text-cyan-400',
    headerBorder: 'border-cyan-500/40',
    cardBg: 'bg-[#070e1f]/90',
    cardBorder: 'border-cyan-500/30',
    primaryBtn: 'bg-gradient-to-r from-cyan-400 to-teal-400 text-black',
    primaryBtnHover: 'hover:from-cyan-300 hover:to-teal-300',
    glowShadow: 'shadow-[0_0_25px_rgba(0,240,255,0.4)]',
    accentPill: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
  },
  synthwave: {
    id: 'synthwave',
    name: 'Synthwave 80s',
    tagline: 'Electric Magenta, Neon Violet & Sunset Orange',
    badge: 'SYNTHWAVE',
    navBg: '#120422',
    navGrid: 'rgba(236, 72, 153, 0.12)',
    navWallFill: '#22083d',
    navWallStroke: '#ec4899',
    navHatch: 'rgba(168, 85, 247, 0.2)',
    operBg: '#080112',
    operWallEcho: 'rgba(236, 72, 153, 0.4)',
    operSonarBase: '#f43f5e',
    primaryAccent: '#ec4899',
    secondaryAccent: '#8b5cf6',
    highlightAccent: '#fbbf24',
    threatRing: '#ef4444',
    threatGlow: '#f43f5e',
    radarLine: 'rgba(236, 72, 153, 0.65)',
    radarSweep: 'rgba(168, 85, 247, 0.45)',
    beaconGlow: '#a855f7',
    datacoreGlow: '#fbbf24',
    extractionGlow: '#22d3ee',
    uiThemeClass: 'theme-synthwave',
    headerAccentText: 'text-pink-400',
    headerBorder: 'border-pink-500/40',
    cardBg: 'bg-[#18082e]/90',
    cardBorder: 'border-pink-500/30',
    primaryBtn: 'bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 text-white',
    primaryBtnHover: 'hover:from-pink-400 hover:via-fuchsia-400 hover:to-purple-500',
    glowShadow: 'shadow-[0_0_25px_rgba(236,72,153,0.45)]',
    accentPill: 'bg-pink-500/20 text-pink-300 border-pink-400/40',
  },
  emerald_matrix: {
    id: 'emerald_matrix',
    name: 'Emerald Matrix',
    tagline: 'High-Tech Neon Lime, Jade & Phosphor Glow',
    badge: 'MATRIX',
    navBg: '#02160d',
    navGrid: 'rgba(16, 185, 129, 0.12)',
    navWallFill: '#06291a',
    navWallStroke: '#10b981',
    navHatch: 'rgba(52, 211, 153, 0.18)',
    operBg: '#010d07',
    operWallEcho: 'rgba(16, 185, 129, 0.4)',
    operSonarBase: '#10b981',
    primaryAccent: '#10b981',
    secondaryAccent: '#06b6d4',
    highlightAccent: '#a3e635',
    threatRing: '#f43f5e',
    threatGlow: '#e11d48',
    radarLine: 'rgba(16, 185, 129, 0.7)',
    radarSweep: 'rgba(52, 211, 153, 0.45)',
    beaconGlow: '#34d399',
    datacoreGlow: '#a3e635',
    extractionGlow: '#38bdf8',
    uiThemeClass: 'theme-matrix',
    headerAccentText: 'text-emerald-400',
    headerBorder: 'border-emerald-500/40',
    cardBg: 'bg-[#042013]/90',
    cardBorder: 'border-emerald-500/30',
    primaryBtn: 'bg-gradient-to-r from-emerald-400 to-teal-400 text-black',
    primaryBtnHover: 'hover:from-emerald-300 hover:to-teal-300',
    glowShadow: 'shadow-[0_0_25px_rgba(16,185,129,0.45)]',
    accentPill: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
  },
  solar_amber: {
    id: 'solar_amber',
    name: 'Solar Flare',
    tagline: 'Warm Radiant Amber, Golden Fire & Crimson Heat',
    badge: 'SOLAR',
    navBg: '#180e03',
    navGrid: 'rgba(245, 158, 11, 0.12)',
    navWallFill: '#2a1805',
    navWallStroke: '#f59e0b',
    navHatch: 'rgba(251, 191, 36, 0.18)',
    operBg: '#0d0701',
    operWallEcho: 'rgba(245, 158, 11, 0.4)',
    operSonarBase: '#f59e0b',
    primaryAccent: '#f59e0b',
    secondaryAccent: '#ef4444',
    highlightAccent: '#38bdf8',
    threatRing: '#ef4444',
    threatGlow: '#dc2626',
    radarLine: 'rgba(245, 158, 11, 0.7)',
    radarSweep: 'rgba(251, 191, 36, 0.45)',
    beaconGlow: '#fbbf24',
    datacoreGlow: '#38bdf8',
    extractionGlow: '#34d399',
    uiThemeClass: 'theme-solar',
    headerAccentText: 'text-amber-400',
    headerBorder: 'border-amber-500/40',
    cardBg: 'bg-[#221305]/90',
    cardBorder: 'border-amber-500/30',
    primaryBtn: 'bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 text-black',
    primaryBtnHover: 'hover:from-amber-300 hover:via-orange-400 hover:to-red-400',
    glowShadow: 'shadow-[0_0_25px_rgba(245,158,11,0.45)]',
    accentPill: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
  },
};
