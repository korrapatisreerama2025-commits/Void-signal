import type {
  KillerDrone,
  LaserBarrier,
  MissionConfig,
  SentinelDrone,
  SonarWave,
  TacticalBeacon,
} from './types';
import {
  TILE_SIZE,
  PLAYER_RADIUS,
  isElectricTileShocking,
  isEntityVisibleToNavigator,
  getClosestThreat,
  getNavigatorViewTransform,
} from './rules';
import { COLOR_THEMES, type ColorThemeId, type ThemeColors } from './themes';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

const MAX_PARTICLES = 250;

export class GameRenderer {
  private particles: Particle[] = [];
  private particleHead: number = 0;

  constructor() {
    // Pre-allocate zero-GC particle pool
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.particles.push({
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        maxLife: 1,
        color: '#fff',
        size: 2,
      });
    }
  }

  public spawnParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    life: number = 0.5,
    size: number = 2
  ) {
    const p = this.particles[this.particleHead];
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.color = color;
    p.life = life;
    p.maxLife = life;
    p.size = size;
    this.particleHead = (this.particleHead + 1) % MAX_PARTICLES;
  }

  public spawnBurst(x: number, y: number, color: string, count: number = 8, speed: number = 60) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
      const spd = speed * (0.6 + Math.random() * 0.8);
      this.spawnParticle(
        x,
        y,
        Math.cos(angle) * spd,
        Math.sin(angle) * spd,
        color,
        0.3 + Math.random() * 0.3,
        2 + Math.random() * 2
      );
    }
  }

  public updateParticles(dt: number) {
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const p = this.particles[i];
      if (p.life > 0) {
        p.life -= dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vx *= 0.94;
        p.vy *= 0.94;
      }
    }
  }

  // Draw Navigator Tactical Blueprint View
  public renderNavigatorView(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    mission: MissionConfig,
    playerX: number,
    playerY: number,
    playerAngle: number,
    isDashing: boolean,
    lasers: LaserBarrier[],
    drones: SentinelDrone[],
    beacons: TacticalBeacon[],
    sonarWaves: SonarWave[],
    doorStates: Record<string, boolean>,
    currentTime: number,
    shakeX: number = 0,
    shakeY: number = 0,
    mouseTarget: { x: number; y: number } | null = null,
    selectedTool: 'ping' | 'beacon' | 'hack' = 'ping',
    exploredGrid?: boolean[][],
    fogOfWarEnabled: boolean = true,
    whistlePulseTimer: number = 0,
    threatOverlayEnabled: boolean = true,
    activeTheme: ColorThemeId = 'cyber_neon',
    killerDrone?: KillerDrone | null
  ) {
    const theme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

    ctx.save();
    ctx.translate(shakeX, shakeY);

    // Dark tactical blueprint background from active theme
    ctx.fillStyle = theme.navBg;
    ctx.fillRect(0, 0, width, height);

    // Subtle themed blueprint grid
    ctx.strokeStyle = theme.navGrid;
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 24) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 24) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Optimal dynamic zoom & centered transform for fullscreen / monitor mode
    const transform = getNavigatorViewTransform(width, height, mission.width, mission.height);
    const { zoom, offsetX, offsetY, mapW, mapH } = transform;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(zoom, zoom);

    // Radar scan radius around player (expands during whistle pulse)
    const activeRadarRadius = whistlePulseTimer > 0 ? 150 + (1 - whistlePulseTimer / 0.6) * 130 : 150;

    // Render floor & tiles
    const rows = mission.grid.length;
    const cols = mission.grid[0].length;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const tile = mission.grid[r][c];
        const tx = c * TILE_SIZE;
        const ty = r * TILE_SIZE;
        const tileCenterX = tx + TILE_SIZE / 2;
        const tileCenterY = ty + TILE_SIZE / 2;

        const isLive = isEntityVisibleToNavigator(
          tileCenterX,
          tileCenterY,
          playerX,
          playerY,
          activeRadarRadius,
          beacons,
          sonarWaves,
          fogOfWarEnabled
        );

        const isExplored = exploredGrid ? (exploredGrid[r]?.[c] ?? false) : true;

        if (fogOfWarEnabled && !isLive) {
          if (!isExplored) {
            // Completely shrouded in sensor darkness
            ctx.fillStyle = '#030710';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
            ctx.strokeStyle = 'rgba(0, 220, 255, 0.025)';
            ctx.strokeRect(tx, ty, TILE_SIZE, TILE_SIZE);
            continue;
          } else {
            // Explored memory wireframe (Navigator remembers layout, but no live entity telemetry)
            if (tile === 1) {
              ctx.fillStyle = 'rgba(8, 18, 32, 0.85)';
              ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
              ctx.strokeStyle = 'rgba(0, 240, 255, 0.12)';
              ctx.lineWidth = 1;
              ctx.strokeRect(tx + 0.5, ty + 0.5, TILE_SIZE - 1, TILE_SIZE - 1);
            } else if (tile === 2) {
              const isOpen = doorStates[`${c},${r}`];
              ctx.strokeStyle = isOpen ? 'rgba(0, 255, 128, 0.25)' : 'rgba(255, 180, 0, 0.25)';
              ctx.lineWidth = 1.5;
              ctx.strokeRect(tx + 4, ty + 4, TILE_SIZE - 8, TILE_SIZE - 8);
            } else if (tile === 6) {
              ctx.strokeStyle = 'rgba(0, 255, 128, 0.3)';
              ctx.lineWidth = 1;
              ctx.strokeRect(tx + 4, ty + 4, TILE_SIZE - 8, TILE_SIZE - 8);
            } else {
              ctx.fillStyle = 'rgba(4, 10, 20, 0.6)';
              ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
              ctx.strokeStyle = 'rgba(0, 240, 255, 0.03)';
              ctx.strokeRect(tx, ty, TILE_SIZE, TILE_SIZE);
            }
            continue;
          }
        }

        // Live illuminated blueprint tile
        if (tile === 1) {
          // Wall: Tech blueprint block
          ctx.fillStyle = theme.navWallFill;
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.strokeStyle = theme.navWallStroke + '66';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(tx + 0.5, ty + 0.5, TILE_SIZE - 1, TILE_SIZE - 1);

          // Diagonal tech hatch pattern inside walls
          ctx.strokeStyle = theme.navHatch;
          ctx.beginPath();
          ctx.moveTo(tx, ty);
          ctx.lineTo(tx + TILE_SIZE, ty + TILE_SIZE);
          ctx.stroke();
        } else if (tile === 2) {
          // Door
          const isOpen = doorStates[`${c},${r}`];
          ctx.fillStyle = isOpen ? 'rgba(0, 255, 128, 0.15)' : 'rgba(255, 180, 0, 0.2)';
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.strokeStyle = isOpen ? '#00ff80' : '#ffb400';
          ctx.lineWidth = 2;
          ctx.strokeRect(tx + 4, ty + 4, TILE_SIZE - 8, TILE_SIZE - 8);

          ctx.fillStyle = isOpen ? '#00ff80' : '#ffb400';
          ctx.font = '9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(isOpen ? 'OPEN' : 'LOCKED', tx + TILE_SIZE / 2, ty + TILE_SIZE / 2 + 3);
        } else if (tile === 3) {
          // Terminal
          ctx.fillStyle = 'rgba(0, 180, 255, 0.2)';
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.strokeStyle = '#00f0ff';
          ctx.strokeRect(tx + 8, ty + 8, TILE_SIZE - 16, TILE_SIZE - 16);
          ctx.fillStyle = '#00f0ff';
          ctx.font = '9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('TERM', tx + TILE_SIZE / 2, ty + TILE_SIZE / 2 + 3);
        } else if (tile === 4) {
          // Keycard
          const isCollected = doorStates['key_collected'];
          if (!isCollected) {
            ctx.fillStyle = 'rgba(255, 215, 0, 0.2)';
            ctx.fillRect(tx + 8, ty + 8, TILE_SIZE - 16, TILE_SIZE - 16);
            ctx.strokeStyle = '#ffd700';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(tx + 12, ty + 12, TILE_SIZE - 24, TILE_SIZE - 24);
            ctx.fillStyle = '#ffd700';
            ctx.font = '8px monospace';
            ctx.textAlign = 'center';
            ctx.fillText('KEY', tx + TILE_SIZE / 2, ty + TILE_SIZE / 2 + 3);
          }
        } else if (tile === 5) {
          // Datacore
          ctx.fillStyle = 'rgba(0, 255, 200, 0.15)';
          ctx.beginPath();
          ctx.arc(tx + 24, ty + 24, 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#00ffc8';
          ctx.stroke();
          ctx.fillStyle = '#00ffc8';
          ctx.font = '8px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('DATA', tx + 24, ty + 27);
        } else if (tile === 6) {
          // Extraction Zone
          const pulse = 0.5 + Math.sin(currentTime * 4) * 0.25;
          ctx.fillStyle = `rgba(0, 255, 128, ${pulse * 0.35})`;
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.strokeStyle = '#00ff80';
          ctx.lineWidth = 2;
          ctx.strokeRect(tx + 2, ty + 2, TILE_SIZE - 4, TILE_SIZE - 4);
          ctx.fillStyle = '#00ff80';
          ctx.font = 'bold 9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('EXIT', tx + TILE_SIZE / 2, ty + TILE_SIZE / 2 + 3);
        } else if (tile === 7) {
          // Electric hazard tile
          const { isWarning, isShocking } = isElectricTileShocking(c, r, currentTime);
          if (isShocking) {
            ctx.fillStyle = 'rgba(255, 60, 60, 0.45)';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
            ctx.strokeStyle = '#ff3344';
            ctx.strokeRect(tx + 2, ty + 2, TILE_SIZE - 4, TILE_SIZE - 4);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 8px monospace';
            ctx.fillText('SHOCK', tx + 24, ty + 27);
          } else if (isWarning) {
            ctx.fillStyle = 'rgba(255, 180, 0, 0.3)';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
            ctx.strokeStyle = '#ffb400';
            ctx.strokeRect(tx + 2, ty + 2, TILE_SIZE - 4, TILE_SIZE - 4);
            ctx.fillStyle = '#ffb400';
            ctx.font = '8px monospace';
            ctx.fillText('WARN', tx + 24, ty + 27);
          } else {
            ctx.fillStyle = 'rgba(100, 100, 150, 0.1)';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
            ctx.strokeStyle = 'rgba(255, 200, 0, 0.2)';
            ctx.strokeRect(tx + 4, ty + 4, TILE_SIZE - 8, TILE_SIZE - 8);
          }
        }
      }
    }

    // Render Laser Barriers (only if in live radar)
    for (const laser of lasers) {
      const midX = (laser.x1 + laser.x2) / 2;
      const midY = (laser.y1 + laser.y2) / 2;
      const isLaserVisible = isEntityVisibleToNavigator(
        midX,
        midY,
        playerX,
        playerY,
        activeRadarRadius,
        beacons,
        sonarWaves,
        fogOfWarEnabled
      );

      if (!isLaserVisible) continue;

      if (laser.isHacked) {
        // Disabled indicator
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(laser.x1, laser.y1);
        ctx.lineTo(laser.x2, laser.y2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = '#00f0ff';
        ctx.font = '8px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('HACKED', midX, midY - 4);
      } else if (laser.isActive) {
        // Active glowing laser line
        ctx.strokeStyle = '#ff0055';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#ff0055';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(laser.x1, laser.y1);
        ctx.lineTo(laser.x2, laser.y2);
        ctx.stroke();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(laser.x1, laser.y1);
        ctx.lineTo(laser.x2, laser.y2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else {
        // Inactive cycle
        ctx.strokeStyle = 'rgba(255, 0, 85, 0.2)';
        ctx.setLineDash([6, 6]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(laser.x1, laser.y1);
        ctx.lineTo(laser.x2, laser.y2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    // Render Drone Patrols & Vision Cones (only if in live radar)
    for (const drone of drones) {
      const isDroneVisible = isEntityVisibleToNavigator(
        drone.x,
        drone.y,
        playerX,
        playerY,
        activeRadarRadius,
        beacons,
        sonarWaves,
        fogOfWarEnabled
      );

      if (!isDroneVisible) continue;

      // Patrol waypoint lines
      if (drone.waypoints.length > 1) {
        ctx.strokeStyle = 'rgba(255, 170, 0, 0.2)';
        ctx.setLineDash([3, 3]);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(drone.waypoints[0].x, drone.waypoints[0].y);
        for (let i = 1; i < drone.waypoints.length; i++) {
          ctx.lineTo(drone.waypoints[i].x, drone.waypoints[i].y);
        }
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Vision cone
      ctx.save();
      ctx.translate(drone.x, drone.y);
      ctx.rotate(drone.angle);

      const coneColor =
        drone.state === 'hunting'
          ? 'rgba(255, 30, 30, 0.35)'
          : drone.alert > 0.3
          ? 'rgba(255, 180, 0, 0.25)'
          : 'rgba(255, 230, 0, 0.12)';

      ctx.fillStyle = coneColor;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, drone.visionRange, -drone.fov / 2, drone.fov / 2);
      ctx.closePath();
      ctx.fill();

      // Drone body
      ctx.fillStyle = drone.state === 'stunned' ? '#556677' : '#ffaa00';
      ctx.beginPath();
      ctx.arc(0, 0, drone.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Heading indicator
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(drone.radius, 0);
      ctx.lineTo(drone.radius - 6, -4);
      ctx.lineTo(drone.radius - 6, 4);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }

    // ==========================================
    // Render Apex Killer Rover (Non-stop Roaming Predator)
    // ==========================================
    if (killerDrone) {
      const isKillerInRadar = isEntityVisibleToNavigator(
        killerDrone.x,
        killerDrone.y,
        playerX,
        playerY,
        activeRadarRadius,
        beacons,
        sonarWaves,
        fogOfWarEnabled
      );

      ctx.save();
      ctx.translate(killerDrone.x, killerDrone.y);

      if (isKillerInRadar) {
        // 1. Pulsing Crimson Danger Field
        const kPulse = Math.sin(currentTime * 8) * 5;
        ctx.fillStyle = 'rgba(255, 0, 60, 0.25)';
        ctx.beginPath();
        ctx.arc(0, 0, 26 + kPulse, 0, Math.PI * 2);
        ctx.fill();

        // 2. Rotating Serrated Threat Reticle
        ctx.save();
        ctx.rotate(currentTime * 3);
        ctx.strokeStyle = '#ff0055';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.arc(0, 0, 22, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        // 3. Directional Hunting Sensor Beam
        ctx.save();
        ctx.rotate(killerDrone.angle);
        const killerBeam = ctx.createRadialGradient(0, 0, 2, 0, 0, 75);
        killerBeam.addColorStop(0, 'rgba(255, 0, 60, 0.5)');
        killerBeam.addColorStop(0.7, 'rgba(255, 0, 60, 0.12)');
        killerBeam.addColorStop(1, 'transparent');
        ctx.fillStyle = killerBeam;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, 75, -Math.PI / 4, Math.PI / 4);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        // 4. Heavily Armored Chassis
        ctx.fillStyle = '#1c0309';
        ctx.strokeStyle = '#ff0055';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#ff0055';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(0, 0, killerDrone.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;

        // 5. Ominous Core Predator Eye
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff0044';
        ctx.beginPath();
        ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // 6. Tactical Predator Header Label
        ctx.fillStyle = '#ff3366';
        ctx.font = 'bold 8px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('KILLER // APEX ROVER', 0, -28);
      } else {
        // Outside sensor link in fog-of-war:
        // Render a faint acoustic seismic warning ripple
        const distToPlayer = Math.hypot(killerDrone.x - playerX, killerDrone.y - playerY);
        if (distToPlayer < 400) {
          const acousticAlpha = Math.max(0.1, 0.45 * (1 - distToPlayer / 400));
          const ripple = (currentTime * 45) % 36;
          ctx.strokeStyle = `rgba(255, 0, 60, ${acousticAlpha})`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(0, 0, 8 + ripple, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = `rgba(255, 60, 90, ${acousticAlpha * 0.8})`;
          ctx.font = '7px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('ACOUSTIC SECTOR DISTURBANCE', 0, -18);
        }
      }

      ctx.restore();
    }

    // Render Fog-of-War Radar Boundary & Sweeping Beam around Operative
    if (fogOfWarEnabled) {
      ctx.save();
      ctx.translate(playerX, playerY);

      // Radar range perimeter dashed ring
      ctx.strokeStyle = theme.radarLine;
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, activeRadarRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Rotating tactical radar line
      const radarAngle = (currentTime * 2.2) % (Math.PI * 2);
      ctx.strokeStyle = theme.radarSweep;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(
        Math.cos(radarAngle) * activeRadarRadius,
        Math.sin(radarAngle) * activeRadarRadius
      );
      ctx.stroke();

      // Sensor link indicator tag
      ctx.fillStyle = theme.primaryAccent;
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('OPERATIVE SENSOR LINK', 0, -activeRadarRadius - 6);
      ctx.restore();
    }

    // Render Tactical Beacons
    for (const beacon of beacons) {
      const pulse = Math.sin(currentTime * 6) * 4;
      ctx.strokeStyle = theme.beaconGlow;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(beacon.x, beacon.y, 14 + pulse, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = theme.beaconGlow;
      ctx.beginPath();
      ctx.arc(beacon.x, beacon.y, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(beacon.label, beacon.x, beacon.y - 18);
    }

    // Render Sonar Waves (Pings)
    for (const wave of sonarWaves) {
      ctx.strokeStyle = wave.color;
      ctx.globalAlpha = wave.opacity;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(wave.x, wave.y, wave.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    }

    // Render Operative Telemetry Marker (The live beacon of player in Navigator blueprint)
    ctx.save();
    ctx.translate(playerX, playerY);

    // Pulse radar ring
    const pingR = 16 + (Math.sin(currentTime * 8) + 1) * 6;
    ctx.strokeStyle = '#00ffcc';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(0, 0, pingR, 0, Math.PI * 2);
    ctx.stroke();

    // Player icon
    ctx.fillStyle = isDashing ? '#ff0077' : '#00ffcc';
    ctx.beginPath();
    ctx.arc(0, 0, PLAYER_RADIUS, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Direction arrow
    ctx.rotate(playerAngle);
    ctx.fillStyle = '#050b14';
    ctx.beginPath();
    ctx.moveTo(PLAYER_RADIUS - 2, 0);
    ctx.lineTo(0, -5);
    ctx.lineTo(0, 5);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    // Draw Navigator interactive crosshair / tool cursor
    if (mouseTarget) {
      const localMX = (mouseTarget.x - offsetX) / zoom;
      const localMY = (mouseTarget.y - offsetY) / zoom;
      ctx.strokeStyle =
        selectedTool === 'hack' ? '#ff0055' : selectedTool === 'beacon' ? '#00f0ff' : '#00ffcc';
      ctx.lineWidth = 1.5 / zoom;
      ctx.beginPath();
      ctx.arc(localMX, localMY, 12, 0, Math.PI * 2);
      ctx.moveTo(localMX - 16, localMY);
      ctx.lineTo(localMX + 16, localMY);
      ctx.moveTo(localMX, localMY - 16);
      ctx.lineTo(localMX, localMY + 16);
      ctx.stroke();
    }

    // ==========================================
    // Threat Proximity Overlay (Immediate Danger to Operative)
    // Highlights closest active drone or active laser barrier with a pulsing red ring
    // ==========================================
    if (threatOverlayEnabled) {
      const threat = getClosestThreat(playerX, playerY, lasers, drones, 360, killerDrone);
      if (threat) {
        ctx.save();

        // 1. Threat Proximity Vector Line (from Operative to Threat)
        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.lineDashOffset = -currentTime * 30;
        ctx.strokeStyle = threat.isCritical ? 'rgba(255, 0, 68, 0.85)' : 'rgba(255, 0, 68, 0.45)';
        ctx.lineWidth = threat.isCritical ? 2 : 1.5;
        ctx.beginPath();
        ctx.moveTo(playerX, playerY);
        ctx.lineTo(threat.x, threat.y);
        ctx.stroke();
        ctx.restore();

        // 2. Primary Pulsing Red Ring centered on threat
        const pulse = Math.sin(currentTime * 9) * 4;
        const baseRadius = threat.type === 'killer' ? 28 : threat.type === 'drone' ? 24 : 18;
        const ringRadius = baseRadius + pulse;

        ctx.shadowColor = '#ff0044';
        ctx.shadowBlur = threat.isCritical ? 18 : 10;
        ctx.strokeStyle = '#ff0044';
        ctx.lineWidth = threat.isCritical ? 3 : 2;
        ctx.beginPath();
        ctx.arc(threat.x, threat.y, ringRadius, 0, Math.PI * 2);
        ctx.stroke();

        // 3. Expanding Secondary Echo Ring
        const echoPhase = (currentTime * 1.6) % 1;
        const echoRadius = baseRadius + echoPhase * 30;
        ctx.strokeStyle = `rgba(255, 0, 68, ${0.85 * (1 - echoPhase)})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(threat.x, threat.y, echoRadius, 0, Math.PI * 2);
        ctx.stroke();

        // 4. Tactical Reticle Brackets
        const bDist = baseRadius + 7;
        const bSize = 6;
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        // Top-left
        ctx.beginPath();
        ctx.moveTo(threat.x - bDist, threat.y - bDist + bSize);
        ctx.lineTo(threat.x - bDist, threat.y - bDist);
        ctx.lineTo(threat.x - bDist + bSize, threat.y - bDist);
        ctx.stroke();
        // Top-right
        ctx.beginPath();
        ctx.moveTo(threat.x + bDist - bSize, threat.y - bDist);
        ctx.lineTo(threat.x + bDist, threat.y - bDist);
        ctx.lineTo(threat.x + bDist, threat.y - bDist + bSize);
        ctx.stroke();
        // Bottom-left
        ctx.beginPath();
        ctx.moveTo(threat.x - bDist, threat.y + bDist - bSize);
        ctx.lineTo(threat.x - bDist, threat.y + bDist);
        ctx.lineTo(threat.x - bDist + bSize, threat.y + bDist);
        ctx.stroke();
        // Bottom-right
        ctx.beginPath();
        ctx.moveTo(threat.x + bDist - bSize, threat.y + bDist);
        ctx.lineTo(threat.x + bDist, threat.y + bDist);
        ctx.lineTo(threat.x + bDist, threat.y + bDist - bSize);
        ctx.stroke();

        ctx.shadowBlur = 0;

        // 5. Tactical Proximity Callout Badge
        const tagX = threat.x;
        const tagY = threat.y - baseRadius - 12;
        const titleText = `⚠ THREAT PROXIMITY [${threat.distance}m]`;
        const descText = threat.name + (threat.isCritical ? ' - CRITICAL DANGER' : '');

        ctx.font = 'bold 9px monospace';
        const tagWidth =
          Math.max(ctx.measureText(titleText).width, ctx.measureText(descText).width) + 16;
        const tagHeight = 26;

        ctx.fillStyle = threat.isCritical ? 'rgba(35, 2, 10, 0.92)' : 'rgba(15, 3, 7, 0.88)';
        ctx.strokeStyle = threat.isCritical ? '#ff0044' : 'rgba(255, 0, 68, 0.7)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(tagX - tagWidth / 2, tagY - tagHeight, tagWidth, tagHeight, 4);
        } else {
          ctx.rect(tagX - tagWidth / 2, tagY - tagHeight, tagWidth, tagHeight);
        }
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = threat.isCritical ? '#ff1744' : '#ff4d6d';
        ctx.textAlign = 'center';
        ctx.fillText(titleText, tagX, tagY - tagHeight + 11);

        ctx.fillStyle = '#ffffff';
        ctx.font = '8px monospace';
        ctx.fillText(descText, tagX, tagY - tagHeight + 21);

        ctx.restore();
      }
    }

    // Border schematic frame and corner brackets
    ctx.strokeStyle = `${theme.primaryAccent}55`;
    ctx.lineWidth = 2;
    ctx.strokeRect(-2, -2, mapW + 4, mapH + 4);

    // High-tech corner brackets
    ctx.strokeStyle = theme.primaryAccent;
    ctx.lineWidth = 2.5;
    const bLen = 14;
    // Top-left
    ctx.beginPath();
    ctx.moveTo(-6, bLen);
    ctx.lineTo(-6, -6);
    ctx.lineTo(bLen, -6);
    ctx.stroke();
    // Top-right
    ctx.beginPath();
    ctx.moveTo(mapW + 6 - bLen, -6);
    ctx.lineTo(mapW + 6, -6);
    ctx.lineTo(mapW + 6, bLen);
    ctx.stroke();
    // Bottom-left
    ctx.beginPath();
    ctx.moveTo(-6, mapH + 6 - bLen);
    ctx.lineTo(-6, mapH + 6);
    ctx.lineTo(bLen, mapH + 6);
    ctx.stroke();
    // Bottom-right
    ctx.beginPath();
    ctx.moveTo(mapW + 6 - bLen, mapH + 6);
    ctx.lineTo(mapW + 6, mapH + 6);
    ctx.lineTo(mapW + 6, mapH + 6 - bLen);
    ctx.stroke();

    ctx.restore(); // map offset & scale
    ctx.restore(); // canvas translation
  }

  // Draw Operative Blind Perspective (Darkness, Echolocation, Tactile Glow)
  public renderOperativeView(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    mission: MissionConfig,
    playerX: number,
    playerY: number,
    playerAngle: number,
    isDashing: boolean,
    lasers: LaserBarrier[],
    drones: SentinelDrone[],
    beacons: TacticalBeacon[],
    sonarWaves: SonarWave[],
    doorStates: Record<string, boolean>,
    currentTime: number,
    shakeX: number = 0,
    shakeY: number = 0,
    whistlePulseTimer: number = 0,
    activeTheme: ColorThemeId = 'cyber_neon',
    killerDrone?: KillerDrone | null
  ) {
    const theme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

    ctx.save();
    ctx.translate(shakeX, shakeY);

    // Deep thematic darkness
    ctx.fillStyle = theme.operBg;
    ctx.fillRect(0, 0, width, height);

    // Dynamic camera centered on player
    const camX = width / 2 - playerX;
    const camY = height / 2 - playerY;

    ctx.save();
    ctx.translate(camX, camY);

    // 1. Draw glowing hazard indicators that pierce darkness (Lasers, Active Electric Floors)
    for (const laser of lasers) {
      if (laser.isActive && !laser.isHacked) {
        // Blinding red energy beam visible even in darkness!
        ctx.strokeStyle = '#ff0055';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#ff0055';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.moveTo(laser.x1, laser.y1);
        ctx.lineTo(laser.x2, laser.y2);
        ctx.stroke();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    }

    // 2. Electric warning sparks / shock flashes
    const rows = mission.grid.length;
    const cols = mission.grid[0].length;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (mission.grid[r][c] === 7) {
          const { isWarning, isShocking } = isElectricTileShocking(c, r, currentTime);
          const tx = c * TILE_SIZE;
          const ty = r * TILE_SIZE;
          if (isShocking) {
            ctx.fillStyle = 'rgba(255, 60, 60, 0.8)';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          } else if (isWarning) {
            ctx.fillStyle = 'rgba(255, 180, 0, 0.35)';
            ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          }
        }
      }
    }

    // 3. Drone Searchlights cutting through the dark
    for (const drone of drones) {
      if (drone.state !== 'stunned') {
        ctx.save();
        ctx.translate(drone.x, drone.y);
        ctx.rotate(drone.angle);

        const lightGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, drone.visionRange);
        lightGrad.addColorStop(
          0,
          drone.state === 'hunting' ? 'rgba(255, 20, 20, 0.7)' : 'rgba(255, 220, 80, 0.5)'
        );
        lightGrad.addColorStop(1, 'rgba(255, 220, 80, 0)');

        ctx.fillStyle = lightGrad;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, drone.visionRange, -drone.fov / 2, drone.fov / 2);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }

    // 4. Tactical Beacons dropped by Navigator (High visibility audio beacon in darkness)
    for (const beacon of beacons) {
      const bPulse = Math.sin(currentTime * 8) * 6;
      ctx.strokeStyle = theme.beaconGlow;
      ctx.lineWidth = 3;
      ctx.shadowColor = theme.beaconGlow;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(beacon.x, beacon.y, 16 + bPulse, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(beacon.x, beacon.y, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = theme.beaconGlow;
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`BEACON: ${beacon.label}`, beacon.x, beacon.y - 24);
    }

    // 5. Sonar Waves (The Operative's primary sense!)
    for (const wave of sonarWaves) {
      ctx.strokeStyle = wave.color;
      ctx.globalAlpha = wave.opacity;
      ctx.lineWidth = 3;
      ctx.shadowColor = wave.color;
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.arc(wave.x, wave.y, wave.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1.0;
    }

    // 6. Whistle Pulse illumination
    if (whistlePulseTimer > 0) {
      const radius = (1 - whistlePulseTimer / 0.6) * 160;
      ctx.strokeStyle = theme.primaryAccent;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(playerX, playerY, radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    // 7. Ambient immediate proximity aura (tactile touch radius ~24px so the runner feels nearby walls)
    const auraGrad = ctx.createRadialGradient(playerX, playerY, 4, playerX, playerY, 32);
    auraGrad.addColorStop(0, theme.primaryAccent + '66');
    auraGrad.addColorStop(0.7, theme.primaryAccent + '1a');
    auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(playerX, playerY, 34, 0, Math.PI * 2);
    ctx.fill();

    // 7.5. Acoustic Echo reflection off Apex Killer Drone
    if (killerDrone) {
      const distToKiller = Math.hypot(killerDrone.x - playerX, killerDrone.y - playerY);
      if (distToKiller < 200 || whistlePulseTimer > 0) {
        const killerEchoAlpha = Math.max(0, 1 - distToKiller / 200) * 0.9;
        if (killerEchoAlpha > 0.05) {
          ctx.save();
          ctx.translate(killerDrone.x, killerDrone.y);
          ctx.strokeStyle = `rgba(255, 0, 60, ${killerEchoAlpha})`;
          ctx.lineWidth = 2.5;
          ctx.shadowColor = '#ff0055';
          ctx.shadowBlur = 14;
          ctx.beginPath();
          ctx.arc(0, 0, killerDrone.radius, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = `rgba(255, 0, 60, ${killerEchoAlpha * 0.4})`;
          ctx.fill();
          ctx.shadowBlur = 0;

          ctx.fillStyle = `rgba(255, 80, 100, ${killerEchoAlpha})`;
          ctx.font = 'bold 9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('! APEX THREAT !', 0, -killerDrone.radius - 8);
          ctx.restore();
        }
      }
    }

    // 8. Player Sprite (Operative in dark)
    ctx.save();
    ctx.translate(playerX, playerY);

    ctx.fillStyle = isDashing ? '#ff0077' : '#00ffcc';
    ctx.beginPath();
    ctx.arc(0, 0, PLAYER_RADIUS, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Heading cone
    ctx.rotate(playerAngle);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(PLAYER_RADIUS, 0);
    ctx.lineTo(PLAYER_RADIUS - 6, -4);
    ctx.lineTo(PLAYER_RADIUS - 6, 4);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    // 9. Particles (Sparks & Echoes)
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const p = this.particles[i];
      if (p.life > 0) {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / p.maxLife;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }
    }

    ctx.restore(); // camera translation

    // 10. Sonar Direction Compass Ring (Perimeter UI indicator showing direction of beacons or pings)
    for (const beacon of beacons) {
      const angle = Math.atan2(beacon.y - playerY, beacon.x - playerX);
      const dist = Math.hypot(beacon.x - playerX, beacon.y - playerY);
      const cx = width / 2;
      const cy = height / 2;
      const r = Math.min(width, height) * 0.42;
      const markerX = cx + Math.cos(angle) * r;
      const markerY = cy + Math.sin(angle) * r;

      ctx.fillStyle = '#00f0ff';
      ctx.beginPath();
      ctx.arc(markerX, markerY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(dist)}m`, markerX, markerY + 16);
    }

    ctx.restore(); // shake
  }
}

export const gameRenderer = new GameRenderer();
