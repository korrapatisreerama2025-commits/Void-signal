export type GameState = 'title' | 'briefing' | 'playing' | 'paused' | 'gameover';

export type PlayMode = 
  | 'splitscreen'      // Both Navigator & Operative on same screen
  | 'solo_runner'      // Player is blind Operative, AI is Navigator
  | 'solo_navigator'   // Player is Navigator, AI is Operative
  | 'dual_window';     // This window renders selected single role, synced over BroadcastChannel

export type PlayerRole = 'navigator' | 'operative';

export type TileType = 
  | 'floor'
  | 'wall'
  | 'door'
  | 'terminal'
  | 'keycard'
  | 'datacore'
  | 'extraction'
  | 'hazard_electric';

export interface Tile {
  x: number;
  y: number;
  type: TileType;
  meta?: {
    doorId?: string;
    isOpen?: boolean;
    keyId?: string;
    isCollected?: boolean;
    terminalId?: string;
    isHacked?: boolean;
    electricCycle?: { on: number; off: number; offset: number };
  };
}

export interface LaserBarrier {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  period: number;      // total cycle seconds
  dutyCycle: number;   // fraction of period active (0..1)
  offset: number;      // phase offset
  isActive: boolean;
  isHacked: boolean;   // disabled for hackDuration
  hackTimer: number;
}

export interface SentinelDrone {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  speed: number;
  waypoints: { x: number; y: number }[];
  currentWaypointIdx: number;
  angle: number;
  fov: number;         // radians (e.g. Math.PI / 3)
  visionRange: number;
  alert: number;       // 0 to 1
  state: 'patrol' | 'investigating' | 'hunting' | 'stunned';
  investigateTarget?: { x: number; y: number };
  stunTimer: number;
}

export interface KillerDrone {
  id: string;
  name: string;
  x: number;
  y: number;
  radius: number;
  speed: number;
  angle: number;
  heading: { dx: number; dy: number };
  nextTileTarget: { x: number; y: number };
  pulseTimer: number;
  state: 'roaming' | 'stalking';
}

export interface TacticalBeacon {
  id: string;
  x: number;
  y: number;
  type: 'waypoint' | 'danger' | 'objective';
  label: string;
  createdAt: number;
  life: number;        // in seconds
}

export interface SonarWave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  speed: number;
  opacity: number;
  isFromOperative: boolean; // if true, drones might detect it
}

export interface RadioMessage {
  id: string;
  sender: 'NAVIGATOR' | 'OPERATIVE' | 'SYSTEM' | 'AI_OVERWATCH';
  text: string;
  time: number;
  urgent?: boolean;
}

export interface MissionHazard {
  name: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  icon: 'laser' | 'drone' | 'electric' | 'door';
  description: string;
}

export interface MissionConfig {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  threatLevel: string;
  objectives: string[];
  hazards: MissionHazard[];
  intelTip: string;
  width: number;
  height: number;
  grid: number[][]; // 1: wall, 0: floor, 2: door, 3: terminal, 4: keycard, 5: datacore, 6: extraction, 7: electric
  startPos: { x: number; y: number };
  extractionPos: { x: number; y: number };
  lasers: LaserBarrier[];
  drones: SentinelDrone[];
  killerDrone?: KillerDrone;
  hackCharges: number;
  timeLimit?: number;
}

export interface GameRunStats {
  missionId: number;
  missionTitle: string;
  clearTime: number;
  alarmsTriggered: number;
  datacoresCollected: number;
  totalDatacores: number;
  pingsEmitted: number;
  hacksUsed: number;
  shieldsRemaining: number;
  rank: 'S' | 'A' | 'B' | 'C';
}
