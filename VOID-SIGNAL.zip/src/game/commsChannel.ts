/**
 * Multi-Window & Peer Synchronization using BroadcastChannel
 * Allows two separate browser tabs (or windows on two screens) to communicate instantly.
 */

export interface CommsPayload {
  type: 
    | 'PLAYER_UPDATE' 
    | 'PING_EMITTED' 
    | 'BEACON_PLACED' 
    | 'HACK_TRIGGERED' 
    | 'RADIO_MESSAGE' 
    | 'GAME_RESTART'
    | 'LEVEL_SELECT'
    | 'ROLE_CLAIM';
  data: any;
  senderRole?: 'navigator' | 'operative';
  timestamp: number;
}

export type CommsListener = (payload: CommsPayload) => void;

class CommsManager {
  private channel: BroadcastChannel | null = null;
  private listeners: Set<CommsListener> = new Set();

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.channel = new BroadcastChannel('void_signal_coop_bus');
        this.channel.onmessage = (event) => {
          this.notify(event.data);
        };
      } catch (err) {
        console.warn('BroadcastChannel not supported or restricted, falling back to local bus');
      }
    }
  }

  public subscribe(listener: CommsListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public broadcast(payload: Omit<CommsPayload, 'timestamp'>) {
    const fullPayload: CommsPayload = {
      ...payload,
      timestamp: Date.now(),
    };
    // Notify local tab listeners as well
    this.notify(fullPayload);
    // Broadcast to other tabs/windows
    if (this.channel) {
      try {
        this.channel.postMessage(fullPayload);
      } catch (e) {
        // ignore
      }
    }
  }

  private notify(payload: CommsPayload) {
    for (const listener of this.listeners) {
      listener(payload);
    }
  }
}

export const comms = new CommsManager();
