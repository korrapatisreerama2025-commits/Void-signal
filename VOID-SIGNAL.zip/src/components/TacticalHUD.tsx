import React, { useState } from 'react';
import type { PlayMode, RadioMessage, KillerDrone } from '../game/types';
import type { DiscoveredDatacore } from '../game/rules';
import { MiniMap } from './MiniMap';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface TacticalHUDProps {
  mode: PlayMode;
  missionTitle: string;
  missionNumber: number;
  shields: number;
  maxShields: number;
  stamina: number;
  hackCharges: number;
  maxHackCharges: number;
  hasKeycard: boolean;
  datacores: number;
  totalDatacores: number;
  elapsedTime: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onOperativePing: () => void;
  onNavigatorToolSelect: (tool: 'ping' | 'beacon' | 'hack') => void;
  selectedNavigatorTool: 'ping' | 'beacon' | 'hack';
  onQuickComms: (text: string) => void;
  activeRadioMessage: RadioMessage | null;
  activeViewRole?: 'navigator' | 'operative' | 'both';
  onSwitchViewRole?: (role: 'navigator' | 'operative' | 'both') => void;
  fogOfWar?: boolean;
  onToggleFog?: () => void;
  threatOverlay?: boolean;
  onToggleThreatOverlay?: () => void;
  // Miniature overview map for Navigator
  missionGrid?: number[][];
  playerX?: number;
  playerY?: number;
  discoveredDatacores?: DiscoveredDatacore[];
  isNavigatorVisible?: boolean;
  killerDrone?: KillerDrone | null;
  // Theme switcher
  activeTheme?: ColorThemeId;
  onSelectTheme?: (theme: ColorThemeId) => void;
}

export const TacticalHUD: React.FC<TacticalHUDProps> = ({
  mode,
  missionTitle,
  missionNumber,
  shields,
  maxShields,
  stamina,
  hackCharges,
  maxHackCharges,
  hasKeycard,
  datacores,
  totalDatacores,
  elapsedTime,
  isMuted,
  onToggleMute,
  onPause,
  onOperativePing,
  onNavigatorToolSelect,
  selectedNavigatorTool,
  onQuickComms,
  activeRadioMessage,
  activeViewRole = 'both',
  onSwitchViewRole,
  fogOfWar = true,
  onToggleFog,
  threatOverlay = true,
  onToggleThreatOverlay,
  missionGrid,
  playerX = 0,
  playerY = 0,
  discoveredDatacores = [],
  isNavigatorVisible = true,
  killerDrone,
  activeTheme = 'cyber_neon',
  onSelectTheme,
}) => {
  const currentTheme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(
    () => typeof document !== 'undefined' && !!document.fullscreenElement
  );

  React.useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-30 flex flex-col justify-between p-3 sm:p-5">
      {/* Top Perimeter Cluster */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Left: Vitality, Stamina & Security Info */}
        <div className="pointer-events-auto flex flex-col gap-2">
          {/* Status Capsule */}
          <div
            className="flex items-center gap-2 sm:gap-3 rounded-lg px-2.5 sm:px-3.5 py-1.5 sm:py-2 shadow-[0_4px_20px_rgba(0,0,0,0.5)] border transition-all"
            style={{
              backgroundColor: `${currentTheme.navBg}ea`,
              borderColor: `${currentTheme.primaryAccent}4d`,
            }}
          >
            <div className="flex flex-col">
              <span
                className="text-[8px] sm:text-[9px] font-mono tracking-widest font-bold uppercase"
                style={{ color: currentTheme.primaryAccent }}
              >
                SECTOR 0{missionNumber}
              </span>
              <span className="text-[11px] sm:text-xs font-mono font-bold text-white tracking-wide truncate max-w-[100px] sm:max-w-none">
                {missionTitle}
              </span>
            </div>

            <div className="h-5 sm:h-6 w-px bg-neutral-700/60" />

            {/* Shield Pips */}
            <div className="flex flex-col">
              <span className="text-[9px] font-mono tracking-widest text-neutral-400 uppercase">
                SHIELDS
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                {Array.from({ length: maxShields }).map((_, idx) => {
                  const isAlive = idx < shields;
                  return (
                    <div
                      key={idx}
                      className={`w-4 h-4 rounded-sm flex items-center justify-center transition-all ${
                        isAlive
                          ? 'border'
                          : 'bg-neutral-900 border border-neutral-700/60'
                      }`}
                      style={
                        isAlive
                          ? {
                              backgroundColor: currentTheme.primaryAccent,
                              borderColor: currentTheme.highlightAccent,
                              boxShadow: `0 0 8px ${currentTheme.primaryAccent}`,
                            }
                          : undefined
                      }
                    >
                      {isAlive ? (
                        <div className="w-1.5 h-1.5 bg-white rounded-xs" />
                      ) : (
                        <div className="w-1.5 h-1.5 bg-neutral-700 rounded-xs" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="h-6 w-px bg-neutral-700/60" />

            {/* Stamina Meter */}
            <div className="flex flex-col min-w-[70px]">
              <div className="flex justify-between text-[9px] font-mono text-neutral-400">
                <span>STAMINA</span>
                <span className="tabular-nums font-bold" style={{ color: currentTheme.highlightAccent }}>
                  {Math.round(stamina)}%
                </span>
              </div>
              <div className="w-full h-2 bg-neutral-900 rounded border border-neutral-800 mt-0.5 overflow-hidden">
                <div
                  className="h-full transition-all duration-75"
                  style={{
                    width: `${Math.max(0, Math.min(100, stamina))}%`,
                    backgroundColor: currentTheme.primaryAccent,
                  }}
                />
              </div>
            </div>

            {/* Hack Charges */}
            <div className="h-6 w-px bg-neutral-700/60" />
            <div className="flex flex-col">
              <span className="text-[9px] font-mono tracking-widest text-neutral-400 uppercase">
                EMP JAM
              </span>
              <div className="flex items-center gap-1 mt-0.5">
                {Array.from({ length: maxHackCharges }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-3 rounded-xs ${
                      i < hackCharges
                        ? 'bg-rose-500 shadow-[0_0_6px_#ff0055]'
                        : 'bg-neutral-800 border border-neutral-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Quick Dual-Screen / Tab View Switcher (if in dual_window mode) */}
          {mode === 'dual_window' && onSwitchViewRole && (
            <div
              className="pointer-events-auto flex items-center gap-1 border rounded px-2 py-1"
              style={{
                backgroundColor: `${currentTheme.navBg}f2`,
                borderColor: `${currentTheme.primaryAccent}4d`,
              }}
            >
              <span className="text-[9px] font-mono text-neutral-400 mr-1">WINDOW ROLE:</span>
              <button
                type="button"
                onClick={() => onSwitchViewRole('navigator')}
                className="text-[10px] font-mono px-2 py-0.5 rounded cursor-pointer transition"
                style={
                  activeViewRole === 'navigator'
                    ? {
                        backgroundColor: currentTheme.primaryAccent,
                        color: '#000000',
                        fontWeight: 'bold',
                      }
                    : { color: '#a3a3a3' }
                }
              >
                THE EYE (NAVIGATOR)
              </button>
              <button
                type="button"
                onClick={() => onSwitchViewRole('operative')}
                className="text-[10px] font-mono px-2 py-0.5 rounded cursor-pointer transition"
                style={
                  activeViewRole === 'operative'
                    ? {
                        backgroundColor: currentTheme.primaryAccent,
                        color: '#000000',
                        fontWeight: 'bold',
                      }
                    : { color: '#a3a3a3' }
                }
              >
                THE BLIND (OPERATIVE)
              </button>
            </div>
          )}
        </div>

        {/* Top-Center: Tactical Radio Transmission Banner */}
        {activeRadioMessage && (
          <div
            className="pointer-events-auto hidden md:flex max-w-md lg:max-w-xl xl:max-w-2xl w-full rounded-lg px-4 py-2.5 shadow-lg animate-bounce duration-500 items-center gap-3 border-2"
            style={{
              backgroundColor: `${currentTheme.navBg}fa`,
              borderColor: currentTheme.primaryAccent,
              boxShadow: `0 0 25px ${currentTheme.primaryAccent}55`,
            }}
          >
            <div
              className="w-2.5 h-2.5 rounded-full animate-ping flex-shrink-0"
              style={{ backgroundColor: currentTheme.primaryAccent }}
            />
            <div className="flex-1 min-w-0">
              <div
                className="flex items-center justify-between text-[9px] font-mono tracking-widest uppercase font-bold"
                style={{ color: currentTheme.primaryAccent }}
              >
                <span>VOID SIGNAL // {activeRadioMessage.sender}</span>
                <span className="text-neutral-400">ACOUSTIC LINK</span>
              </div>
              <div className="text-xs sm:text-sm font-mono font-bold text-white tracking-wide truncate">
                "{activeRadioMessage.text}"
              </div>
            </div>
          </div>
        )}

        {/* Top-Right: Utilities (Theme switcher, Mute, Threat, Pause, Timer) */}
        <div className="pointer-events-auto flex items-center gap-2 relative">
          {/* Mission Timer */}
          <div
            className="border rounded-lg px-3 py-1.5 text-right font-mono shadow-md"
            style={{
              backgroundColor: `${currentTheme.navBg}ea`,
              borderColor: `${currentTheme.primaryAccent}4d`,
            }}
          >
            <div className="text-[9px] tracking-widest text-neutral-400">TIME</div>
            <div
              className="text-sm font-bold tabular-nums"
              style={{ color: currentTheme.primaryAccent }}
            >
              {Math.floor(elapsedTime / 60)}:
              {(Math.floor(elapsedTime % 60)).toString().padStart(2, '0')}
            </div>
          </div>

          {/* Theme Quick Switcher Toggle Button */}
          {onSelectTheme && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowThemePicker(!showThemePicker)}
                title="Switch Visual Color Theme"
                className="h-9 px-2.5 rounded-lg border flex items-center gap-1.5 transition cursor-pointer font-mono text-[10px] font-bold"
                style={{
                  backgroundColor: `${currentTheme.navBg}ea`,
                  borderColor: currentTheme.primaryAccent,
                  color: currentTheme.primaryAccent,
                  boxShadow: `0 0 10px ${currentTheme.primaryAccent}33`,
                }}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: currentTheme.primaryAccent }}
                />
                <span className="hidden sm:inline uppercase">{currentTheme.badge}</span>
                <svg
                  className={`w-3 h-3 transition-transform ${showThemePicker ? 'rotate-180' : ''}`}
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>

              {/* Dropdown theme drawer */}
              {showThemePicker && (
                <div
                  className="absolute right-0 top-11 z-50 w-52 rounded-xl p-2 border shadow-2xl flex flex-col gap-1 backdrop-blur-md"
                  style={{
                    backgroundColor: `${currentTheme.navBg}fa`,
                    borderColor: `${currentTheme.primaryAccent}66`,
                    boxShadow: `0 8px 30px rgba(0,0,0,0.8), 0 0 20px ${currentTheme.primaryAccent}33`,
                  }}
                >
                  <div className="text-[9px] font-mono text-neutral-400 px-2 py-1 font-bold uppercase tracking-wider">
                    PALETTE PRESETS:
                  </div>
                  {(Object.keys(COLOR_THEMES) as ColorThemeId[]).map((tId) => {
                    const themeObj = COLOR_THEMES[tId];
                    const isCur = activeTheme === tId;
                    return (
                      <button
                        key={tId}
                        type="button"
                        onClick={() => {
                          onSelectTheme(tId);
                          setShowThemePicker(false);
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-left font-mono text-[11px] flex items-center justify-between transition cursor-pointer ${
                          isCur
                            ? 'font-bold'
                            : 'text-neutral-300 hover:bg-neutral-800/60'
                        }`}
                        style={
                          isCur
                            ? {
                                backgroundColor: `${themeObj.primaryAccent}22`,
                                color: themeObj.primaryAccent,
                                border: `1px solid ${themeObj.primaryAccent}66`,
                              }
                            : undefined
                        }
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                            style={{ backgroundColor: themeObj.primaryAccent }}
                          />
                          <span>{themeObj.name}</span>
                        </div>
                        {isCur && <span className="text-[10px]">●</span>}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Threat Proximity Overlay Toggle Button */}
          {onToggleThreatOverlay && (
            <button
              type="button"
              onClick={onToggleThreatOverlay}
              aria-label={threatOverlay ? 'Threat Proximity Overlay ON' : 'Threat Proximity Overlay OFF'}
              title={
                threatOverlay
                  ? 'Threat Proximity: Active (Click to toggle)'
                  : 'Threat Proximity: Inactive (Click to toggle)'
              }
              className={`h-9 px-2.5 rounded-lg border flex items-center gap-1.5 transition cursor-pointer font-mono text-[10px] font-bold ${
                threatOverlay
                  ? 'bg-rose-950/60 border-rose-500/80 text-rose-300 shadow-[0_0_10px_rgba(255,0,68,0.25)]'
                  : 'bg-[#050b14]/90 border-neutral-700 text-neutral-400 hover:text-white'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  threatOverlay ? 'bg-rose-500 animate-pulse' : 'bg-neutral-600'
                }`}
              />
              <span className="hidden sm:inline">THREAT PROXIMITY</span>
            </button>
          )}

          {/* Fullscreen / Monitor Mode Toggle Button */}
          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit Fullscreen [F]' : 'Fullscreen Monitor Mode [F]'}
            title={isFullscreen ? 'Exit Fullscreen [F]' : 'Fullscreen / Monitor Mode [F]'}
            className="h-9 px-2.5 rounded-lg border bg-neutral-900/80 text-white flex items-center gap-1.5 transition cursor-pointer font-mono text-[10px] font-bold"
            style={{
              borderColor: `${currentTheme.primaryAccent}4d`,
              color: currentTheme.primaryAccent,
            }}
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {isFullscreen ? (
                <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" />
              ) : (
                <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
              )}
            </svg>
            <span className="hidden md:inline">{isFullscreen ? 'WINDOWED' : 'FULLSCREEN'}</span>
          </button>

          {/* Mute Toggle Button */}
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute Audio [M]' : 'Mute Audio [M]'}
            title="Toggle Audio [M]"
            className={`w-9 h-9 rounded-lg border flex items-center justify-center transition cursor-pointer ${
              isMuted
                ? 'bg-rose-950/40 border-rose-600/60 text-rose-400'
                : 'bg-neutral-900/80 border-neutral-700 text-white hover:border-neutral-500'
            }`}
            style={
              !isMuted
                ? {
                    borderColor: `${currentTheme.primaryAccent}4d`,
                    color: currentTheme.primaryAccent,
                  }
                : undefined
            }
          >
            {isMuted ? (
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 5L6 9H2v6h4l5 4V5zM23 9l-6 6M17 9l6 6" />
              </svg>
            ) : (
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 5L6 9H2v6h4l5 4V5zM15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" />
              </svg>
            )}
          </button>

          {/* Pause Button */}
          <button
            type="button"
            onClick={onPause}
            aria-label="Pause Mission [Esc / P]"
            title="Pause Mission [Esc / P]"
            className="w-9 h-9 rounded-lg border bg-neutral-900/80 text-white flex items-center justify-center transition cursor-pointer"
            style={{
              borderColor: `${currentTheme.primaryAccent}4d`,
              color: currentTheme.primaryAccent,
            }}
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Bottom Perimeter Cluster: Objectives & Tactical Action Decks */}
      <div className="flex items-end justify-between gap-4">
        {/* Bottom-Left: Operative Objectives & Whistle */}
        <div className="pointer-events-auto flex flex-col gap-2">
          {/* Objectives Card */}
          <div
            className="flex items-center gap-3 rounded-lg px-3.5 py-2 text-white font-mono shadow-md border"
            style={{
              backgroundColor: `${currentTheme.navBg}ea`,
              borderColor: `${currentTheme.primaryAccent}4d`,
            }}
          >
            <div className="flex items-center gap-2">
              <div
                className={`w-2.5 h-2.5 rounded-full ${
                  hasKeycard
                    ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                    : 'bg-amber-400 animate-pulse'
                }`}
              />
              <span className="text-xs">
                {hasKeycard ? 'KEYCARD ACQUIRED' : 'LOCATE KEYCARD'}
              </span>
            </div>

            {totalDatacores > 0 && (
              <>
                <div className="h-5 w-px bg-neutral-700/60" />
                <div
                  className="text-xs font-bold"
                  style={{ color: currentTheme.highlightAccent }}
                >
                  DATACORES: {datacores}/{totalDatacores}
                </div>
              </>
            )}
          </div>

          {/* Echolocation Whistle Button */}
          <button
            type="button"
            onClick={onOperativePing}
            className="group flex items-center gap-2 border rounded-lg px-3 py-2 text-xs font-mono transition cursor-pointer active:scale-95 shadow-md"
            style={{
              backgroundColor: `${currentTheme.secondaryAccent}22`,
              borderColor: currentTheme.secondaryAccent,
              color: '#ffffff',
            }}
          >
            <svg
              className="w-4 h-4 group-hover:scale-110 transition"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              style={{ color: currentTheme.secondaryAccent }}
            >
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="5" />
              <circle cx="12" cy="12" r="1" fill="currentColor" />
            </svg>
            <span>ECHOLOCATION PULSE [E / SPACE]</span>
          </button>
        </div>

        {/* Bottom-Right: Tactical Comms Wheel & Navigator Drone Tools & Mini-map */}
        <div className="pointer-events-auto flex items-end gap-2.5">
          {/* Miniature Tactical Overview Map (Visible to Navigator at all times) */}
          {isNavigatorVisible && missionGrid && missionGrid.length > 0 && (
            <div className="hidden sm:block flex-shrink-0">
              <MiniMap
                grid={missionGrid}
                playerX={playerX}
                playerY={playerY}
                discoveredDatacores={discoveredDatacores}
                activeTheme={activeTheme}
                killerDrone={killerDrone}
              />
            </div>
          )}

          {/* Action and Radio Deck */}
          <div className="flex flex-col items-end gap-1.5 sm:gap-2">
            {/* Quick Tactical Radio Dispatch Buttons */}
            <div
              className="hidden sm:block rounded-lg p-2 shadow-md border"
              style={{
                backgroundColor: `${currentTheme.navBg}ea`,
                borderColor: `${currentTheme.primaryAccent}4d`,
              }}
            >
            <div
              className="text-[9px] font-mono tracking-wider mb-1 uppercase font-bold"
              style={{ color: currentTheme.primaryAccent }}
            >
              QUICK RADIO TRANSMISSION:
            </div>
            <div className="flex flex-wrap gap-1 max-w-[260px] justify-end">
              {[
                { label: 'NORTH', cmd: 'Advance North' },
                { label: 'SOUTH', cmd: 'Advance South' },
                { label: 'EAST', cmd: 'Advance East' },
                { label: 'WEST', cmd: 'Advance West' },
                { label: 'HOLD', cmd: 'Hold position! Wait.' },
                { label: 'LASER', cmd: 'Laser barrier ahead!' },
                { label: 'DRONE', cmd: 'Drone patrol nearby, stay quiet!' },
                { label: 'RUN', cmd: 'Path clear, sprint now!' },
              ].map((btn) => (
                <button
                  key={btn.label}
                  type="button"
                  onClick={() => onQuickComms(btn.cmd)}
                  className="px-1.5 py-0.5 border text-white font-mono text-[9px] font-bold rounded transition cursor-pointer active:scale-95"
                  style={{
                    backgroundColor: `${currentTheme.primaryAccent}22`,
                    borderColor: `${currentTheme.primaryAccent}55`,
                  }}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Navigator Tool Selection Tray */}
          <div
            className="flex items-center gap-1 rounded-lg p-1 sm:p-1.5 shadow-md border"
            style={{
              backgroundColor: `${currentTheme.navBg}ea`,
              borderColor: `${currentTheme.primaryAccent}4d`,
            }}
          >
            <span className="hidden sm:inline text-[9px] font-mono text-neutral-400 px-1 uppercase">
              TOOLS:
            </span>
            <button
              type="button"
              onClick={() => onNavigatorToolSelect('ping')}
              className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded font-mono text-[10px] sm:text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedNavigatorTool === 'ping'
                  ? 'text-black shadow-md'
                  : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-700'
              }`}
              style={
                selectedNavigatorTool === 'ping'
                  ? {
                      backgroundColor: currentTheme.primaryAccent,
                      boxShadow: `0 0 10px ${currentTheme.primaryAccent}`,
                    }
                  : undefined
              }
            >
              <span>1</span> PING
            </button>
            <button
              type="button"
              onClick={() => onNavigatorToolSelect('beacon')}
              className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded font-mono text-[10px] sm:text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedNavigatorTool === 'beacon'
                  ? 'text-black shadow-md'
                  : 'bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-700'
              }`}
              style={
                selectedNavigatorTool === 'beacon'
                  ? {
                      backgroundColor: currentTheme.primaryAccent,
                      boxShadow: `0 0 10px ${currentTheme.primaryAccent}`,
                    }
                  : undefined
              }
            >
              <span>2</span> BEACON
            </button>
            <button
              type="button"
              onClick={() => onNavigatorToolSelect('hack')}
              className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded font-mono text-[10px] sm:text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedNavigatorTool === 'hack'
                  ? 'bg-rose-500 text-white shadow-[0_0_10px_#ff0055]'
                  : 'bg-neutral-900 text-rose-300 hover:text-white border border-neutral-700'
              }`}
            >
              <span>3</span> HACK ({hackCharges})
            </button>

            {/* Fog of War Toggle */}
            {onToggleFog && (
              <button
                type="button"
                onClick={onToggleFog}
                title="Toggle Tactical Fog-of-War Sensor Link"
                className={`px-2 py-1 sm:py-1.5 rounded font-mono text-[9px] sm:text-[10px] font-bold transition cursor-pointer flex items-center gap-1 border ${
                  fogOfWar
                    ? 'border text-white shadow-sm'
                    : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-white'
                }`}
                style={
                  fogOfWar
                    ? {
                        backgroundColor: `${currentTheme.primaryAccent}22`,
                        borderColor: `${currentTheme.primaryAccent}88`,
                        color: currentTheme.primaryAccent,
                      }
                    : undefined
                }
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${fogOfWar ? 'animate-pulse' : 'bg-neutral-600'}`}
                  style={fogOfWar ? { backgroundColor: currentTheme.primaryAccent } : undefined}
                />
                <span className="hidden sm:inline">RADAR FOG:</span>
                <span>{fogOfWar ? 'ON' : 'OFF'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};
