import React from 'react';
import type { ClosestThreat } from '../game/rules';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface OperativeVignetteProps {
  speedRatio: number; // 0 (still) to 1 (full sprint)
  isDashing: boolean;
  threat: ClosestThreat | null;
  activeTheme?: ColorThemeId;
}

export const OperativeVignette: React.FC<OperativeVignetteProps> = ({
  speedRatio,
  isDashing,
  threat,
  activeTheme = 'cyber_neon',
}) => {
  const theme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

  // Threat danger factor from 0 (far/none) to 1 (immediate collision danger)
  let threatFactor = 0;
  let isCritical = false;
  if (threat) {
    // Threat distance is in pixels or meters. Threat distance < 200 triggers awareness, < 75 is critical
    threatFactor = Math.max(0, Math.min(1, 1 - threat.distance / 200));
    isCritical = threat.isCritical || threat.distance < 75;
  }

  // Dynamic clear sight radius in pitch darkness:
  // When idle: darkness closes in (tunnel vision ~16% radius).
  // When running: vision widens slightly (~26% radius) but pulses rapidly with footstep exertion.
  const innerRadius = Math.round(16 + speedRatio * 10);
  const midRadius = Math.round(innerRadius + 22 + (1 - speedRatio) * 6);
  const outerRadius = Math.round(midRadius + 28);

  // Pulse rate based on movement speed:
  // Idle: 3.2s slow breath; Walking: 1.4s; Sprinting: 0.65s rapid breathing
  const pulseDuration = isDashing ? '0.6s' : speedRatio > 0.2 ? '1.2s' : '3.0s';

  // Danger perimeter color based on threat and theme
  const threatGlowSpread = Math.round(40 + threatFactor * 90);
  const threatAlpha = (0.2 + threatFactor * 0.7).toFixed(2);

  return (
    <div
      data-testid="operative-vignette-overlay"
      className="absolute inset-0 pointer-events-none select-none overflow-hidden z-20"
      aria-hidden="true"
    >
      {/* Layer 1: Base Pitch Darkness Tunnel Radial Gradient */}
      <div
        className={`absolute inset-0 transition-opacity duration-300 ${
          isDashing ? 'animate-sprint-distort' : 'animate-darkness-breathe'
        }`}
        style={{
          animationDuration: pulseDuration,
          background: `radial-gradient(ellipse at 50% 50%, transparent ${innerRadius}%, rgba(0, 0, 0, 0.45) ${midRadius}%, rgba(1, 2, 7, 0.94) ${outerRadius}%, #000000 100%)`,
        }}
      />

      {/* Layer 2: Movement Motion Blur & Tunnel Edge Compression */}
      <div
        className="absolute inset-0 transition-all duration-150"
        style={{
          boxShadow: `inset 0 0 ${Math.round(60 + speedRatio * 90)}px rgba(0, 0, 0, 0.98), inset 0 0 ${Math.round(
            120 + speedRatio * 60
          )}px rgba(0, 0, 0, ${isDashing ? 0.92 : 0.75})`,
          opacity: 0.85 + speedRatio * 0.15,
        }}
      />

      {/* Layer 3: Dynamic Threat Proximity Danger Pulse */}
      {threatFactor > 0 && (
        <div
          className={`absolute inset-0 transition-all duration-200 ${
            isCritical ? 'animate-threat-panic' : ''
          }`}
          style={{
            background: `radial-gradient(circle at 50% 50%, transparent ${Math.max(
              10,
              innerRadius - 4
            )}%, rgba(255, 0, 60, ${Math.min(0.35, threatFactor * 0.4)}) ${midRadius}%, rgba(80, 0, 20, ${
              threatFactor * 0.75
            }) ${outerRadius}%, rgba(20, 0, 5, 0.95) 100%)`,
            boxShadow: `inset 0 0 ${threatGlowSpread}px rgba(255, 0, 60, ${threatAlpha})`,
          }}
        />
      )}

      {/* Layer 4: Chromatic Fringes during Sprinting */}
      {isDashing && (
        <div
          className="absolute inset-0 opacity-40 mix-blend-screen"
          style={{
            boxShadow: `inset 0 0 80px ${theme.secondaryAccent}`,
          }}
        />
      )}

      {/* Layer 5: Subtle Sensory Biometric HUD Ribbon at Viewport Bottom */}
      <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[9px] font-mono tracking-widest text-neutral-400/80 pointer-events-none">
        <div className="flex items-center gap-2">
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              threatFactor > 0.5
                ? 'bg-rose-500 animate-ping shadow-[0_0_6px_#ff0055]'
                : speedRatio > 0.1
                ? 'bg-cyan-400 animate-pulse'
                : 'bg-neutral-600'
            }`}
          />
          <span
            className={
              isCritical
                ? 'text-rose-400 font-bold animate-pulse'
                : threatFactor > 0.2
                ? 'text-rose-300 font-semibold'
                : 'text-neutral-400'
            }
          >
            {isCritical
              ? `HAZARD WARNING // PROXIMITY CRITICAL [${threat?.distance ?? 0}m]`
              : threatFactor > 0.2
              ? `THREAT SENSE // ${threat?.name ?? 'HAZARD'} NEARBY`
              : speedRatio > 0.5
              ? 'LOCOMOTION // VELOCITY HIGH'
              : 'SENSORY // PITCH BLACKNESS'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span>PULSE RATE:</span>
          <span
            className={`font-bold tabular-nums ${
              isCritical
                ? 'text-rose-400 animate-pulse'
                : speedRatio > 0.5
                ? 'text-amber-400'
                : 'text-neutral-400'
            }`}
          >
            {Math.round(72 + speedRatio * 45 + threatFactor * 55)} BPM
          </span>
        </div>
      </div>
    </div>
  );
};
