import React, { useEffect, useRef } from 'react';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface CyberBackgroundProps {
  activeTheme?: ColorThemeId;
  interactive?: boolean;
  intensity?: 'medium' | 'high' | 'ultra';
}

interface CyberParticle {
  x: number;
  y: number;
  z: number;
  vz: number;
  size: number;
  alpha: number;
  colorType: 'primary' | 'secondary' | 'highlight' | 'white';
}

interface LightStreak {
  x: number;
  y: number;
  length: number;
  speed: number;
  alpha: number;
  width: number;
}

export const CyberBackground: React.FC<CyberBackgroundProps> = ({
  activeTheme = 'cyber_neon',
  interactive = true,
  intensity = 'high',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const theme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

  const mousePosRef = useRef<{ x: number; y: number; targetX: number; targetY: number }>({
    x: 0.5,
    y: 0.5,
    targetX: 0.5,
    targetY: 0.5,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive) return;
      mousePosRef.current.targetX = e.clientX / width;
      mousePosRef.current.targetY = e.clientY / height;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Initialize 3D Cyber Particles
    const particleCount = intensity === 'ultra' ? 180 : intensity === 'high' ? 130 : 80;
    const particles: CyberParticle[] = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: (Math.random() - 0.5) * 2200,
        y: (Math.random() - 0.5) * 1200,
        z: Math.random() * 1000 + 10,
        vz: Math.random() * 2.5 + 2.0,
        size: Math.random() * 2.5 + 1.0,
        alpha: Math.random() * 0.8 + 0.2,
        colorType:
          Math.random() < 0.55
            ? 'primary'
            : Math.random() < 0.85
            ? 'secondary'
            : 'highlight',
      });
    }

    // Initialize Vertical Cyber Data Light Streaks
    const streakCount = 24;
    const streaks: LightStreak[] = [];
    for (let i = 0; i < streakCount; i++) {
      streaks.push({
        x: Math.random() * width,
        y: Math.random() * height,
        length: Math.random() * 120 + 60,
        speed: Math.random() * 4 + 3,
        alpha: Math.random() * 0.4 + 0.1,
        width: Math.random() * 2 + 1,
      });
    }

    let gridOffset = 0;
    let time = 0;

    const render = () => {
      time += 0.016;
      gridOffset = (gridOffset + 1.8) % 60;

      // Smooth mouse lerping
      const mouse = mousePosRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      const curTheme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

      // 1. Deep Space Atmospheric Gradient with Theme Radial Glow
      const bgGrad = ctx.createRadialGradient(
        width * 0.5 + (mouse.x - 0.5) * 100,
        height * 0.48 + (mouse.y - 0.5) * 80,
        20,
        width * 0.5,
        height * 0.5,
        Math.max(width, height) * 0.85
      );
      bgGrad.addColorStop(0, curTheme.navBg);
      bgGrad.addColorStop(0.4, '#040711');
      bgGrad.addColorStop(1, '#010206');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // 2. Horizon Sun / Core Cyber Vortex Glow
      const horizonY = height * 0.55 + (mouse.y - 0.5) * 60;
      const vanishingX = width * 0.5 + (mouse.x - 0.5) * 120;

      const sunGrad = ctx.createRadialGradient(
        vanishingX,
        horizonY,
        10,
        vanishingX,
        horizonY,
        Math.min(width, height) * 0.45
      );
      sunGrad.addColorStop(0, `${curTheme.primaryAccent}44`);
      sunGrad.addColorStop(0.3, `${curTheme.secondaryAccent}22`);
      sunGrad.addColorStop(0.7, `${curTheme.primaryAccent}08`);
      sunGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(vanishingX, horizonY, Math.min(width, height) * 0.45, 0, Math.PI * 2);
      ctx.fill();

      // 3. Concentric Tactical Radar Scanning Rings at Horizon
      const ringCount = 3;
      for (let r = 1; r <= ringCount; r++) {
        const ringRadius = ((time * 40 + r * 140) % (width * 0.45));
        const ringAlpha = Math.max(0, 1 - ringRadius / (width * 0.45)) * 0.25;
        ctx.strokeStyle = curTheme.primaryAccent;
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = ringAlpha;
        ctx.beginPath();
        ctx.ellipse(
          vanishingX,
          horizonY,
          ringRadius,
          ringRadius * 0.35,
          0,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // 4. Moving 3D Perspective Wireframe Floor Grid
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, horizonY - 1, width, height - horizonY + 2);
      ctx.clip();

      const fov = 350;
      const cameraY = 160;

      // Perspective Depth Grid Lines (Transverse rungs)
      const maxZ = 1200;
      const zStep = 45;
      for (let z = ((gridOffset * 2) % zStep) + 10; z < maxZ; z += zStep) {
        const screenY = horizonY + (cameraY * fov) / z;
        if (screenY > height + 20) break;

        const depthFade = Math.max(0, 1 - z / maxZ);
        ctx.strokeStyle = curTheme.primaryAccent;
        ctx.lineWidth = Math.max(0.5, (1 - z / maxZ) * 2.2);
        ctx.globalAlpha = depthFade * 0.35;

        ctx.beginPath();
        ctx.moveTo(0, screenY);
        ctx.lineTo(width, screenY);
        ctx.stroke();
      }

      // Perspective Longitudinal Grid Lines (Radiating outward from horizon)
      const numLongLines = 26;
      for (let i = -numLongLines / 2; i <= numLongLines / 2; i++) {
        const worldX = i * 85;
        const nearZ = 30;
        const farZ = maxZ;

        const x1 = vanishingX + (worldX * fov) / farZ;
        const y1 = horizonY + (cameraY * fov) / farZ;
        const x2 = vanishingX + (worldX * fov) / nearZ;
        const y2 = horizonY + (cameraY * fov) / nearZ;

        const edgeDist = Math.abs(i) / (numLongLines / 2);
        ctx.strokeStyle = i % 2 === 0 ? curTheme.primaryAccent : curTheme.secondaryAccent;
        ctx.lineWidth = Math.max(0.6, (1 - edgeDist) * 1.8);
        ctx.globalAlpha = (1 - edgeDist * 0.4) * 0.28;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      ctx.restore();
      ctx.globalAlpha = 1;

      // 5. Ceiling Tech Canopy (Inverted subtle wireframe roof for high intensity sci-fi tunnel feel)
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, width, horizonY);
      ctx.clip();

      const ceilCamY = -180;
      for (let z = ((gridOffset * 2) % zStep) + 15; z < maxZ * 0.8; z += zStep * 1.5) {
        const screenY = horizonY + (ceilCamY * fov) / z;
        if (screenY < -10) break;

        const depthFade = Math.max(0, 1 - z / (maxZ * 0.8));
        ctx.strokeStyle = curTheme.secondaryAccent;
        ctx.lineWidth = 1;
        ctx.globalAlpha = depthFade * 0.12;

        ctx.beginPath();
        ctx.moveTo(0, screenY);
        ctx.lineTo(width, screenY);
        ctx.stroke();
      }

      for (let i = -14; i <= 14; i += 2) {
        const worldX = i * 110;
        const x1 = vanishingX + (worldX * fov) / (maxZ * 0.8);
        const y1 = horizonY + (ceilCamY * fov) / (maxZ * 0.8);
        const x2 = vanishingX + (worldX * fov) / 40;
        const y2 = horizonY + (ceilCamY * fov) / 40;

        ctx.strokeStyle = curTheme.secondaryAccent;
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.08;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      ctx.restore();
      ctx.globalAlpha = 1;

      // 6. Horizon Neon Dividing Laser Beam
      const horizonGlow = ctx.createLinearGradient(0, horizonY, width, horizonY);
      horizonGlow.addColorStop(0, 'transparent');
      horizonGlow.addColorStop(0.2, curTheme.primaryAccent);
      horizonGlow.addColorStop(0.5, '#ffffff');
      horizonGlow.addColorStop(0.8, curTheme.secondaryAccent);
      horizonGlow.addColorStop(1, 'transparent');

      ctx.strokeStyle = horizonGlow;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = curTheme.primaryAccent;
      ctx.shadowBlur = 16;
      ctx.beginPath();
      ctx.moveTo(0, horizonY);
      ctx.lineTo(width, horizonY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // 7. Animated Vertical Data Stream Streaks
      for (const streak of streaks) {
        streak.y += streak.speed;
        if (streak.y > height) {
          streak.y = -streak.length;
          streak.x = Math.random() * width;
        }

        const streakGrad = ctx.createLinearGradient(
          streak.x,
          streak.y,
          streak.x,
          streak.y + streak.length
        );
        streakGrad.addColorStop(0, 'transparent');
        streakGrad.addColorStop(0.7, `${curTheme.highlightAccent}88`);
        streakGrad.addColorStop(1, '#ffffff');

        ctx.strokeStyle = streakGrad;
        ctx.lineWidth = streak.width;
        ctx.globalAlpha = streak.alpha;
        ctx.beginPath();
        ctx.moveTo(streak.x, streak.y);
        ctx.lineTo(streak.x, streak.y + streak.length);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // 8. 3D Cyber Particles & Dust Orbs streaming towards viewer
      for (const p of particles) {
        p.z -= p.vz;
        if (p.z <= 1) {
          p.z = 1000;
          p.x = (Math.random() - 0.5) * 2200;
          p.y = (Math.random() - 0.5) * 1200;
        }

        const screenX = vanishingX + (p.x * fov) / p.z;
        const screenY = horizonY + (p.y * fov) / p.z;

        if (screenX < -20 || screenX > width + 20 || screenY < -20 || screenY > height + 20) {
          continue;
        }

        const pSize = Math.max(0.8, (p.size * fov) / p.z);
        const pAlpha = Math.min(1, ((1000 - p.z) / 1000) * p.alpha);

        let color = curTheme.primaryAccent;
        if (p.colorType === 'secondary') color = curTheme.secondaryAccent;
        if (p.colorType === 'highlight') color = curTheme.highlightAccent;
        if (p.colorType === 'white') color = '#ffffff';

        // Draw particle with subtle glow trail
        ctx.fillStyle = color;
        ctx.globalAlpha = pAlpha;
        ctx.beginPath();
        ctx.arc(screenX, screenY, pSize, 0, Math.PI * 2);
        ctx.fill();

        // Speed motion trail when particle is close
        if (p.z < 350) {
          const trailLength = (1 - p.z / 350) * 14;
          const prevScreenX = vanishingX + (p.x * fov) / (p.z + trailLength * 2);
          const prevScreenY = horizonY + (p.y * fov) / (p.z + trailLength * 2);

          ctx.strokeStyle = color;
          ctx.lineWidth = pSize * 0.8;
          ctx.beginPath();
          ctx.moveTo(prevScreenX, prevScreenY);
          ctx.lineTo(screenX, screenY);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;

      // 9. Floating Constellation Connection Conduits between proximate nodes
      const sampleLimit = Math.min(30, particles.length);
      ctx.lineWidth = 0.75;
      for (let i = 0; i < sampleLimit; i++) {
        const p1 = particles[i];
        if (p1.z > 500) continue;
        const x1 = vanishingX + (p1.x * fov) / p1.z;
        const y1 = horizonY + (p1.y * fov) / p1.z;

        for (let j = i + 1; j < sampleLimit; j++) {
          const p2 = particles[j];
          if (p2.z > 500) continue;
          const x2 = vanishingX + (p2.x * fov) / p2.z;
          const y2 = horizonY + (p2.y * fov) / p2.z;

          const dx = x2 - x1;
          const dy = y2 - y1;
          const distSq = dx * dx + dy * dy;

          if (distSq < 110 * 110) {
            const lineAlpha = (1 - Math.sqrt(distSq) / 110) * 0.25;
            ctx.strokeStyle = curTheme.primaryAccent;
            ctx.globalAlpha = lineAlpha;
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1;

      // 10. Ambient Vignette Edge Treatment
      const vignette = ctx.createRadialGradient(
        width * 0.5,
        height * 0.5,
        Math.min(width, height) * 0.45,
        width * 0.5,
        height * 0.5,
        Math.max(width, height) * 0.75
      );
      vignette.addColorStop(0, 'transparent');
      vignette.addColorStop(1, 'rgba(1, 2, 6, 0.75)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, width, height);

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [activeTheme, interactive, intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
      style={{ display: 'block' }}
    />
  );
};
