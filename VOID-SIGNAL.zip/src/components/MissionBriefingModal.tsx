import React, { useEffect } from 'react';
import type { MissionConfig, PlayMode } from '../game/types';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface MissionBriefingModalProps {
  mission: MissionConfig;
  mode: PlayMode;
  onCommence: () => void;
  onBack: () => void;
  activeTheme?: ColorThemeId;
}

export const MissionBriefingModal: React.FC<MissionBriefingModalProps> = ({
  mission,
  mode,
  onCommence,
  onBack,
  activeTheme = 'cyber_neon',
}) => {
  const currentTheme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

  // Bind Enter/Space to commence and Escape to back
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        onCommence();
      } else if (e.code === 'Escape') {
        e.preventDefault();
        onBack();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onCommence, onBack]);

  const severityBadgeColors = {
    LOW: 'bg-emerald-950/60 text-emerald-400 border-emerald-700/60',
    MEDIUM: 'bg-amber-950/60 text-amber-400 border-amber-700/60',
    HIGH: 'bg-orange-950/60 text-orange-400 border-orange-700/60',
    CRITICAL: 'bg-rose-950/60 text-rose-400 border-rose-700/60 shadow-[0_0_8px_rgba(244,63,94,0.3)]',
  };

  const modeLabels = {
    splitscreen: 'SPLIT SCREEN (LOCAL CO-OP)',
    solo_runner: 'SOLO OPERATIVE (AI OVERWATCH)',
    solo_navigator: 'SOLO NAVIGATOR (SCOUT BOT)',
    dual_window: 'DUAL SCREEN / MULTI-WINDOW CHANNEL',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none">
      <div
        className="w-full max-w-3xl xl:max-w-4xl bg-[#070e1b] border-2 rounded-xl p-6 sm:p-8 text-white flex flex-col gap-6 max-h-[90vh] overflow-y-auto"
        style={{
          borderColor: currentTheme.primaryAccent,
          boxShadow: `0 0 50px ${currentTheme.primaryAccent}40`,
        }}
      >
        {/* Header Classification Stripe */}
        <div
          className="flex items-center justify-between border-b pb-4"
          style={{ borderColor: `${currentTheme.primaryAccent}33` }}
        >
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span
                className="w-2.5 h-2.5 rounded-full animate-pulse"
                style={{
                  backgroundColor: currentTheme.primaryAccent,
                  boxShadow: `0 0 8px ${currentTheme.primaryAccent}`,
                }}
              />
              <span
                className="text-[10px] font-mono tracking-[0.25em] font-bold uppercase"
                style={{ color: currentTheme.primaryAccent }}
              >
                VOID SIGNAL DOSSIER // SECTOR 0{mission.id}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-mono font-black tracking-wide text-white mt-1">
              {mission.title}
            </h2>
            <div className="text-xs font-mono text-neutral-400 tracking-wider">
              {mission.subtitle} · PROTOCOL: {modeLabels[mode]} · SECTOR GRID: {mission.width}x{mission.height}
            </div>
          </div>

          {/* Threat Level Badge */}
          <div className="bg-rose-950/40 border border-rose-500/60 rounded px-3 py-1.5 text-right font-mono">
            <div className="text-[9px] text-rose-400 tracking-widest uppercase">THREAT ASSESSMENT</div>
            <div className="text-xs sm:text-sm font-bold text-rose-300 tracking-wide">
              {mission.threatLevel}
            </div>
          </div>
        </div>

        {/* Narrative Description */}
        <p
          className="text-xs sm:text-sm text-neutral-300 font-sans leading-relaxed border-l-2 pl-3 italic"
          style={{ borderColor: currentTheme.primaryAccent }}
        >
          "{mission.description}"
        </p>

        {/* 2-Column Content: Objectives & Environmental Hazards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Section 1: Infiltration Objectives */}
          <div className="bg-neutral-950/70 border border-neutral-800 rounded-lg p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
              <svg
                className="w-4 h-4"
                style={{ color: currentTheme.primaryAccent }}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 6v6l4 2" />
              </svg>
              <h3
                className="font-mono text-xs font-bold tracking-wider uppercase"
                style={{ color: currentTheme.primaryAccent }}
              >
                MISSION OBJECTIVES
              </h3>
            </div>
            <ul className="space-y-2 text-xs font-mono text-neutral-300">
              {mission.objectives.map((obj, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <span
                    className="w-3.5 h-3.5 rounded-xs border flex items-center justify-center flex-shrink-0 mt-0.5 text-[9px] font-bold"
                    style={{
                      borderColor: currentTheme.primaryAccent,
                      color: currentTheme.primaryAccent,
                    }}
                  >
                    ✓
                  </span>
                  <span className="leading-tight">{obj}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section 2: Detected Environmental Hazards */}
          <div className="bg-neutral-950/70 border border-neutral-800 rounded-lg p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
              <svg className="w-4 h-4 text-rose-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                <line x1="12" y1="9" x2="12" y2="13" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
              <h3 className="font-mono text-xs font-bold text-rose-400 tracking-wider uppercase">
                ENVIRONMENTAL HAZARDS
              </h3>
            </div>
            <div className="space-y-2.5">
              {mission.hazards.map((haz, i) => (
                <div key={i} className="flex flex-col gap-1 border border-neutral-800 rounded p-2 bg-neutral-900/40">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-neutral-200">
                      {haz.name}
                    </span>
                    <span
                      className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                        severityBadgeColors[haz.severity]
                      }`}
                    >
                      {haz.severity}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 font-sans leading-tight">
                    {haz.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tactical Advisory Banner */}
        <div
          className="rounded-lg p-3 flex items-start gap-3 border"
          style={{
            backgroundColor: `${currentTheme.primaryAccent}10`,
            borderColor: `${currentTheme.primaryAccent}40`,
          }}
        >
          <div
            className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-mono font-bold"
            style={{
              backgroundColor: `${currentTheme.primaryAccent}25`,
              color: currentTheme.primaryAccent,
            }}
          >
            i
          </div>
          <div className="flex flex-col">
            <span
              className="text-[10px] font-mono font-bold tracking-wider uppercase"
              style={{ color: currentTheme.primaryAccent }}
            >
              CO-OP ACOUSTIC TACTICAL ADVISORY
            </span>
            <span className="text-xs text-neutral-300 font-sans leading-snug mt-0.5">
              {mission.intelTip}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 font-mono text-sm">
          <button
            type="button"
            data-start="true"
            onClick={onCommence}
            className={`w-full sm:flex-1 py-3.5 font-mono font-bold tracking-[0.2em] rounded-xl transition cursor-pointer active:scale-95 text-center flex items-center justify-center gap-2 ${currentTheme.primaryBtn} ${currentTheme.primaryBtnHover} ${currentTheme.glowShadow}`}
          >
            COMMENCE INFILTRATION [ENTER / SPACE]
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </button>
          <button
            type="button"
            onClick={onBack}
            className="w-full sm:w-auto px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded-xl border border-neutral-700 transition cursor-pointer text-center"
          >
            BACK [ESC]
          </button>
        </div>
      </div>
    </div>
  );
};
