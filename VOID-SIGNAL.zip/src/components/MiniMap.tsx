import React, { useMemo } from 'react';
import type { DiscoveredDatacore } from '../game/rules';
import type { KillerDrone } from '../game/types';
import { TILE_SIZE } from '../game/rules';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface MiniMapProps {
  grid: number[][];
  playerX: number;
  playerY: number;
  discoveredDatacores: DiscoveredDatacore[];
  exploredGrid?: boolean[][];
  showAllBlueprint?: boolean;
  activeTheme?: ColorThemeId;
  killerDrone?: KillerDrone | null;
}

interface TileCoord {
  x: number;
  y: number;
}

export const MiniMap: React.FC<MiniMapProps> = ({
  grid,
  playerX,
  playerY,
  discoveredDatacores,
  exploredGrid,
  showAllBlueprint = true,
  activeTheme = 'cyber_neon',
  killerDrone,
}) => {
  const theme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;
  const rows = grid.length;
  const cols = rows > 0 ? grid[0].length : 0;

  // Mini-map dimensions: dynamically scaled to remain compact for large mazes
  const miniTileSize = cols >= 30 ? 5.5 : cols >= 25 ? 6.5 : 7.5;
  const miniMapWidth = Math.round(cols * miniTileSize);
  const miniMapHeight = Math.round(rows * miniTileSize);

  // Player position relative to grid
  const playerMiniX = (playerX / TILE_SIZE) * miniTileSize;
  const playerMiniY = (playerY / TILE_SIZE) * miniTileSize;

  // Killer position relative to grid
  const killerMiniX = killerDrone ? (killerDrone.x / TILE_SIZE) * miniTileSize : 0;
  const killerMiniY = killerDrone ? (killerDrone.y / TILE_SIZE) * miniTileSize : 0;

  // Memoize static tile rects
  const { walls, exits, doors } = useMemo(() => {
    const wallList: TileCoord[] = [];
    const exitList: TileCoord[] = [];
    const doorList: TileCoord[] = [];

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const val = grid[r][c];
        const x = c * miniTileSize;
        const y = r * miniTileSize;

        if (val === 1) {
          wallList.push({ x, y });
        } else if (val === 6) {
          exitList.push({ x, y });
        } else if (val === 2) {
          doorList.push({ x, y });
        }
      }
    }

    return { walls: wallList, exits: exitList, doors: doorList };
  }, [grid, rows, cols, miniTileSize]);

  if (rows === 0 || cols === 0) return null;

  return (
    <div
      data-testid="hud-minimap"
      className="flex flex-col rounded-lg p-2 shadow-[0_4px_24px_rgba(0,0,0,0.7)] backdrop-blur-xs select-none transition-all duration-300"
      style={{
        backgroundColor: theme.navBg,
        borderColor: theme.primaryAccent + '66',
        borderWidth: '1px',
      }}
    >
      {/* Header bar */}
      <div
        className="flex items-center justify-between pb-1 mb-1.5 font-mono text-[9px]"
        style={{ borderBottom: `1px solid ${theme.primaryAccent}40` }}
      >
        <div className="flex items-center gap-1.5">
          <span
            className="w-1.5 h-1.5 rounded-full shadow-[0_0_6px] animate-pulse"
            style={{ backgroundColor: theme.primaryAccent }}
          />
          <span className="font-bold tracking-widest uppercase" style={{ color: theme.primaryAccent }}>
            NAVIGATOR TACTICAL OVERVIEW
          </span>
        </div>
        <span className="text-neutral-400 font-mono text-[8px]">
          SECTOR GRID: {cols}x{rows}
        </span>
      </div>

      {/* Mini-map SVG Canvas */}
      <div
        className="relative rounded overflow-hidden flex items-center justify-center"
        style={{
          border: `1px solid ${theme.primaryAccent}4d`,
          backgroundColor: theme.operBg,
        }}
      >
        <svg
          width={miniMapWidth}
          height={miniMapHeight}
          viewBox={`0 0 ${miniMapWidth} ${miniMapHeight}`}
          className="block"
        >
          {/* Subtle Grid pattern */}
          <defs>
            <pattern
              id="minimapGrid"
              width={miniTileSize}
              height={miniTileSize}
              patternUnits="userSpaceOnUse"
            >
              <rect
                width={miniTileSize}
                height={miniTileSize}
                fill="none"
                stroke={theme.navGrid}
                strokeWidth="0.5"
              />
            </pattern>
          </defs>

          <rect width={miniMapWidth} height={miniMapHeight} fill="url(#minimapGrid)" />

          {/* Maze Walls */}
          {walls.map((w: TileCoord, idx: number) => (
            <rect
              key={`wall_${idx}`}
              x={w.x}
              y={w.y}
              width={miniTileSize}
              height={miniTileSize}
              fill={theme.navWallFill}
              stroke={theme.navWallStroke + '55'}
              strokeWidth="0.5"
            />
          ))}

          {/* Security Doors */}
          {doors.map((d: TileCoord, idx: number) => (
            <rect
              key={`door_${idx}`}
              x={d.x + 1}
              y={d.y + 1}
              width={miniTileSize - 2}
              height={miniTileSize - 2}
              fill="rgba(255, 180, 0, 0.25)"
              stroke="#ffb400"
              strokeWidth="0.75"
            />
          ))}

          {/* Extraction Zone (Exit) */}
          {exits.map((e: TileCoord, idx: number) => (
            <g key={`exit_${idx}`}>
              <rect
                x={e.x + 0.5}
                y={e.y + 0.5}
                width={miniTileSize - 1}
                height={miniTileSize - 1}
                fill="rgba(0, 255, 128, 0.35)"
                stroke="#00ff80"
                strokeWidth="1"
              />
              <circle
                cx={e.x + miniTileSize / 2}
                cy={e.y + miniTileSize / 2}
                r={2}
                fill="#00ff80"
              />
            </g>
          ))}

          {/* Discovered Datacores */}
          {discoveredDatacores.map((dc, idx) => {
            const dcMiniX = (dc.worldX / TILE_SIZE) * miniTileSize;
            const dcMiniY = (dc.worldY / TILE_SIZE) * miniTileSize;
            return (
              <g key={`dc_${dc.gridX}_${dc.gridY}_${idx}`}>
                <circle
                  cx={dcMiniX}
                  cy={dcMiniY}
                  r={3.5}
                  fill="none"
                  stroke={theme.highlightAccent}
                  strokeWidth="0.75"
                  className="animate-pulse"
                />
                <circle
                  cx={dcMiniX}
                  cy={dcMiniY}
                  r={1.75}
                  fill={theme.highlightAccent}
                />
              </g>
            );
          })}

          {/* Apex Killer Drone Marker */}
          {killerDrone && (
            <g>
              <circle
                cx={killerMiniX}
                cy={killerMiniY}
                r={5.5}
                fill="none"
                stroke="#ff0055"
                strokeWidth="0.8"
                opacity="0.85"
              />
              <rect
                x={killerMiniX - 2}
                y={killerMiniY - 2}
                width={4}
                height={4}
                fill="#ff0055"
                transform={`rotate(45 ${killerMiniX} ${killerMiniY})`}
              />
            </g>
          )}

          {/* Operative Player Blip */}
          <g>
            {/* Pulsing beacon radar ring */}
            <circle
              cx={playerMiniX}
              cy={playerMiniY}
              r={6}
              fill="none"
              stroke={theme.primaryAccent}
              strokeWidth="0.75"
              strokeOpacity="0.8"
            />
            {/* Player marker core */}
            <circle
              cx={playerMiniX}
              cy={playerMiniY}
              r={2.5}
              fill={theme.primaryAccent}
            />
          </g>
        </svg>
      </div>

      {/* Mini-map Footer Legend */}
      <div className="flex items-center justify-between text-[7px] font-mono text-neutral-400 mt-1.5 px-0.5">
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: theme.primaryAccent }} />
          <span>RUNNER</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 bg-[#00ff80] rounded-xs" />
          <span>EXTRACTION</span>
        </div>
        {killerDrone && (
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-[#ff0055] rounded-xs animate-pulse" />
            <span className="text-rose-400 font-bold">KILLER</span>
          </div>
        )}
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: theme.highlightAccent }} />
          <span>DATA</span>
        </div>
      </div>
    </div>
  );
};
