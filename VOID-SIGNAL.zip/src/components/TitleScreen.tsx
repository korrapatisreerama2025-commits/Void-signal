import React, { useState, useEffect } from 'react';
import type { PlayMode } from '../game/types';
import { CAMPAIGN_MISSIONS } from '../game/rules';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';
import { CyberBackground } from './CyberBackground';

interface TitleScreenProps {
  onStart: (mode: PlayMode, missionIdx: number) => void;
  selectedMode: PlayMode;
  setSelectedMode: (mode: PlayMode) => void;
  selectedMissionIdx: number;
  setSelectedMissionIdx: (idx: number) => void;
  activeTheme?: ColorThemeId;
  onSelectTheme?: (theme: ColorThemeId) => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  selectedMode,
  setSelectedMode,
  selectedMissionIdx,
  setSelectedMissionIdx,
  activeTheme = 'cyber_neon',
  onSelectTheme,
}) => {
  const currentTheme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

  const gradientDefs: Record<ColorThemeId, { stop1: string; stop2: string; stop3: string }> = {
    cyber_neon: { stop1: '#00f0ff', stop2: '#ffffff', stop3: '#00ffc8' },
    synthwave: { stop1: '#f43f5e', stop2: '#ec4899', stop3: '#a855f7' },
    emerald_matrix: { stop1: '#10b981', stop2: '#a7f3d0', stop3: '#a3e635' },
    solar_amber: { stop1: '#f59e0b', stop2: '#fef08a', stop3: '#ef4444' },
  };

  const currentGradient = gradientDefs[activeTheme] || gradientDefs.cyber_neon;

  const [isFullscreen, setIsFullscreen] = React.useState<boolean>(() => typeof document !== 'undefined' && !!document.fullscreenElement);

  React.useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex flex-col justify-between p-4 sm:p-8 xl:p-12 select-none overflow-y-auto"
      style={{ backgroundColor: currentTheme.navBg }}
    >
      {/* High-Intensity 3D Moving Cyber Grid & Particle Background */}
      <CyberBackground activeTheme={activeTheme} intensity="high" />

      {/* Top Header Tactical Banner */}
      <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div
            className="w-3 h-3 rounded-full animate-pulse"
            style={{
              backgroundColor: currentTheme.primaryAccent,
              boxShadow: `0 0 10px ${currentTheme.primaryAccent}`,
            }}
          />
          <span
            className="font-mono text-xs tracking-[0.25em] font-bold uppercase"
            style={{ color: currentTheme.primaryAccent }}
          >
            VOID SIGNAL NETWORK · ASYMMETRIC INFILTRATION
          </span>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-mono text-[10px] font-bold uppercase transition cursor-pointer hover:scale-105 active:scale-95"
            style={{
              borderColor: `${currentTheme.primaryAccent}66`,
              color: currentTheme.primaryAccent,
              backgroundColor: `${currentTheme.primaryAccent}15`,
            }}
            title="Toggle Fullscreen / Monitor Mode [F]"
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {isFullscreen ? (
                <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" />
              ) : (
                <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
              )}
            </svg>
            <span>{isFullscreen ? 'WINDOWED' : 'FULLSCREEN'}</span>
          </button>
          <span className="font-mono text-[11px] text-neutral-400 tracking-wider">
            SYSTEM STATUS: ONLINE
          </span>
          <span
            className="font-mono text-[10px] font-bold px-2 py-0.5 rounded border uppercase"
            style={{
              color: currentTheme.primaryAccent,
              borderColor: `${currentTheme.primaryAccent}55`,
              backgroundColor: `${currentTheme.primaryAccent}15`,
            }}
          >
            {currentTheme.badge} ACTIVE
          </span>
        </div>
      </div>

      {/* Centerpiece: Bespoke SVG Title Lockup & Config */}
      <div className="relative z-10 max-w-5xl xl:max-w-6xl mx-auto w-full my-auto flex flex-col items-center text-center py-4">
        {/* Custom Inline SVG Title Lockup */}
        <div className="mb-5 flex flex-col items-center">
          <svg
            viewBox="0 0 680 120"
            className="w-full max-w-[620px] h-auto"
            style={{
              filter: `drop-shadow(0 0 28px ${currentTheme.primaryAccent}55)`,
            }}
          >
            <defs>
              <linearGradient id="themeTitleGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={currentGradient.stop1} />
                <stop offset="50%" stopColor={currentGradient.stop2} />
                <stop offset="100%" stopColor={currentGradient.stop3} />
              </linearGradient>
            </defs>
            {/* Labyrinth Crest Graphic */}
            <path
              d="M 280 14 L 400 14 M 270 20 L 410 20 M 340 4 L 340 28"
              stroke={currentTheme.primaryAccent}
              strokeWidth="2"
              strokeOpacity="0.8"
              fill="none"
            />
            {/* Title Text */}
            <text
              x="340"
              y="74"
              textAnchor="middle"
              fill="url(#themeTitleGrad)"
              fontFamily="monospace"
              fontWeight="900"
              fontSize="48"
              letterSpacing="10"
            >
              VOID SIGNAL
            </text>
            <text
              x="340"
              y="104"
              textAnchor="middle"
              fill={currentTheme.secondaryAccent}
              fontFamily="monospace"
              fontWeight="700"
              fontSize="14"
              letterSpacing="6"
            >
              COOPERATIVE BLIND MAZE PROTOCOL
            </text>
          </svg>
          <p className="max-w-2xl text-neutral-300 text-xs sm:text-sm font-sans tracking-wide leading-relaxed mt-2">
            One player sees the lethal blueprint but <strong style={{ color: currentTheme.primaryAccent }}>cannot move</strong>.
            The other maneuvers but is <strong style={{ color: currentTheme.secondaryAccent }}>completely blind</strong> in pitch darkness.
            Precision acoustic communication is survival.
          </p>
        </div>

        {/* COLOR THEME SELECTOR BAR */}
        <div className="w-full max-w-3xl xl:max-w-4xl bg-black/60 border border-neutral-800 rounded-xl p-3.5 mb-4 shadow-lg backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2.5 px-1">
            <span
              className="text-[11px] font-mono tracking-wider font-bold flex items-center gap-1.5"
              style={{ color: currentTheme.primaryAccent }}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: currentTheme.primaryAccent }} />
              VISUAL COLOR PALETTE THEME:
            </span>
            <span className="text-[11px] font-mono text-neutral-400">
              {currentTheme.name}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(Object.keys(COLOR_THEMES) as ColorThemeId[]).map((themeKey) => {
              const t = COLOR_THEMES[themeKey];
              const isSelected = activeTheme === themeKey;
              return (
                <button
                  key={themeKey}
                  type="button"
                  onClick={() => onSelectTheme?.(themeKey)}
                  className={`p-2 rounded-lg border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                    isSelected
                      ? 'scale-[1.02] shadow-md'
                      : 'hover:border-neutral-700 bg-neutral-950/60 opacity-80 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: isSelected ? `${t.primaryAccent}15` : undefined,
                    borderColor: isSelected ? t.primaryAccent : '#262626',
                    boxShadow: isSelected ? `0 0 14px ${t.primaryAccent}40` : undefined,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="font-mono text-[10px] font-bold tracking-wide uppercase"
                      style={{ color: isSelected ? t.primaryAccent : '#d4d4d4' }}
                    >
                      {t.badge}
                    </span>
                    {/* Swatch dots */}
                    <div className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: t.primaryAccent }} />
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: t.secondaryAccent }} />
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: t.highlightAccent }} />
                    </div>
                  </div>
                  <div className="text-[11px] font-medium text-white leading-tight truncate">
                    {t.name}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Operational Mode Selector */}
        <div className="w-full max-w-2xl bg-black/60 border border-neutral-800 rounded-xl p-3.5 mb-5 shadow-lg backdrop-blur-sm">
          <div
            className="text-xs font-mono tracking-wider mb-2.5 text-left font-bold"
            style={{ color: currentTheme.primaryAccent }}
          >
            SELECT INFILTRATION PROTOCOL:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => setSelectedMode('splitscreen')}
              className={`p-3 rounded-lg border text-left transition cursor-pointer ${
                selectedMode === 'splitscreen'
                  ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                  : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
              }`}
              style={
                selectedMode === 'splitscreen'
                  ? {
                      borderColor: currentTheme.primaryAccent,
                      backgroundColor: `${currentTheme.primaryAccent}1a`,
                      color: '#ffffff',
                      boxShadow: `0 0 12px ${currentTheme.primaryAccent}33`,
                    }
                  : undefined
              }
            >
              <div className="font-mono text-xs font-bold tracking-wide">SPLIT SCREEN</div>
              <div className="text-[11px] text-neutral-400 mt-0.5 leading-tight">
                Two players on one screen (Navigator + Runner side-by-side).
              </div>
            </button>
            <button
              type="button"
              onClick={() => setSelectedMode('solo_runner')}
              className={`p-3 rounded-lg border text-left transition cursor-pointer ${
                selectedMode === 'solo_runner'
                  ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                  : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
              }`}
              style={
                selectedMode === 'solo_runner'
                  ? {
                      borderColor: currentTheme.primaryAccent,
                      backgroundColor: `${currentTheme.primaryAccent}1a`,
                      color: '#ffffff',
                      boxShadow: `0 0 12px ${currentTheme.primaryAccent}33`,
                    }
                  : undefined
              }
            >
              <div className="font-mono text-xs font-bold tracking-wide">SOLO RUNNER (AI EYE)</div>
              <div className="text-[11px] text-neutral-400 mt-0.5 leading-tight">
                You play blind Operative; AI Navigator gives audio pings & voice cues.
              </div>
            </button>
            <button
              type="button"
              onClick={() => setSelectedMode('dual_window')}
              className={`p-3 rounded-lg border text-left transition cursor-pointer ${
                selectedMode === 'dual_window'
                  ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                  : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
              }`}
              style={
                selectedMode === 'dual_window'
                  ? {
                      borderColor: currentTheme.primaryAccent,
                      backgroundColor: `${currentTheme.primaryAccent}1a`,
                      color: '#ffffff',
                      boxShadow: `0 0 12px ${currentTheme.primaryAccent}33`,
                    }
                  : undefined
              }
            >
              <div className="font-mono text-xs font-bold tracking-wide">DUAL TABS / 2 SCREENS</div>
              <div className="text-[11px] text-neutral-400 mt-0.5 leading-tight">
                Open in 2 browser tabs or monitors; syncs via live channel!
              </div>
            </button>
          </div>
        </div>

        {/* Mission Sector Selector */}
        <div className="w-full max-w-3xl xl:max-w-4xl bg-black/60 border border-neutral-800 rounded-xl p-3.5 mb-6 shadow-lg backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <span
              className="text-xs font-mono tracking-wider font-bold"
              style={{ color: currentTheme.primaryAccent }}
            >
              TARGET FACILITY SECTOR:
            </span>
            <span className="text-xs font-mono text-neutral-400">
              MISSION {selectedMissionIdx + 1} / {CAMPAIGN_MISSIONS.length}
            </span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {CAMPAIGN_MISSIONS.map((m, idx) => {
              const isMissionSelected = selectedMissionIdx === idx;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setSelectedMissionIdx(idx)}
                  className={`flex-1 min-w-[120px] py-2 px-2.5 rounded-lg text-left border transition cursor-pointer font-mono ${
                    isMissionSelected
                      ? 'text-white'
                      : 'border-neutral-800 bg-neutral-950/40 text-neutral-400 hover:border-neutral-700'
                  }`}
                  style={
                    isMissionSelected
                      ? {
                          borderColor: currentTheme.primaryAccent,
                          backgroundColor: `${currentTheme.primaryAccent}22`,
                          boxShadow: `0 0 10px ${currentTheme.primaryAccent}33`,
                        }
                      : undefined
                  }
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="text-[10px] font-bold"
                      style={{ color: isMissionSelected ? currentTheme.primaryAccent : '#a3a3a3' }}
                    >
                      M0{m.id}
                    </span>
                    <span className="text-[9px] text-neutral-500 font-mono">
                      {m.width}x{m.height}
                    </span>
                  </div>
                  <div className="text-xs truncate">{m.title}</div>
                </button>
              );
            })}
          </div>
          <div className="text-xs text-neutral-300 mt-2 text-left font-sans italic">
            "{CAMPAIGN_MISSIONS[selectedMissionIdx].description}"
          </div>
        </div>

        {/* Primary Start CTA Button */}
        <button
          type="button"
          data-start="true"
          onClick={() => onStart(selectedMode, selectedMissionIdx)}
          className={`group relative inline-flex items-center justify-center px-10 py-4 font-mono font-bold text-sm tracking-[0.2em] rounded-xl transition cursor-pointer active:scale-95 ${currentTheme.primaryBtn} ${currentTheme.primaryBtnHover} ${currentTheme.glowShadow}`}
        >
          <span className="relative z-10 flex items-center gap-2">
            START INFILTRATION
            <svg
              className="w-4 h-4 transition group-hover:translate-x-1"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </span>
        </button>
      </div>

      {/* Flat Clean Control Hint Line at Bottom Safe Margin */}
      <div className="relative z-10 text-center font-mono text-xs text-neutral-400 tracking-wider">
        WASD / Arrows Move · Space Action · E Echolocation Ping · M Mute · Esc Pause
      </div>
    </div>
  );
};
