import React, { useEffect } from 'react';
import type { GameRunStats } from '../game/types';
import { COLOR_THEMES, type ColorThemeId } from '../game/themes';

interface StatusModalsProps {
  state: 'paused' | 'victory' | 'gameover';
  stats: GameRunStats | null;
  onResume: () => void;
  onRestart: () => void;
  onTitle: () => void;
  onNextMission?: () => void;
  hasNextMission?: boolean;
  activeTheme?: ColorThemeId;
}

export const StatusModals: React.FC<StatusModalsProps> = ({
  state,
  stats,
  onResume,
  onRestart,
  onTitle,
  onNextMission,
  hasNextMission = false,
  activeTheme = 'cyber_neon',
}) => {
  const currentTheme = COLOR_THEMES[activeTheme] || COLOR_THEMES.cyber_neon;

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (state === 'paused') {
        if (e.code === 'Escape' || e.code === 'KeyP') {
          e.preventDefault();
          onResume();
        } else if (e.code === 'KeyR') {
          e.preventDefault();
          onRestart();
        }
      } else if (state === 'victory') {
        if (e.code === 'Enter' || e.code === 'Space') {
          e.preventDefault();
          if (hasNextMission && onNextMission) {
            onNextMission();
          } else {
            onRestart();
          }
        } else if (e.code === 'KeyR') {
          e.preventDefault();
          onRestart();
        }
      } else if (state === 'gameover') {
        if (e.code === 'Enter' || e.code === 'KeyR' || e.code === 'Space') {
          e.preventDefault();
          onRestart();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state, onResume, onRestart, onNextMission, hasNextMission]);

  if (state === 'paused') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 select-none">
        <div
          className="w-full max-w-md border rounded-xl p-6 shadow-2xl text-white text-center"
          style={{
            backgroundColor: `${currentTheme.navBg}fa`,
            borderColor: `${currentTheme.primaryAccent}66`,
            boxShadow: `0 0 40px ${currentTheme.primaryAccent}33`,
          }}
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <span
              className="w-2 h-2 rounded-full animate-pulse"
              style={{ backgroundColor: currentTheme.primaryAccent }}
            />
            <h2
              className="font-mono text-sm tracking-[0.25em] font-bold uppercase"
              style={{ color: currentTheme.primaryAccent }}
            >
              INFILTRATION SUSPENDED
            </h2>
          </div>
          <h3 className="text-2xl font-mono font-bold tracking-wider mb-6">MISSION PAUSED</h3>

          <div className="space-y-3 font-mono text-sm">
            <button
              type="button"
              data-start="true"
              onClick={onResume}
              className={`w-full py-3 font-bold tracking-widest rounded-lg transition cursor-pointer ${currentTheme.primaryBtn} ${currentTheme.primaryBtnHover} ${currentTheme.glowShadow}`}
            >
              RESUME [ESC / P]
            </button>
            <button
              type="button"
              onClick={onRestart}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 tracking-wider rounded-lg transition cursor-pointer border border-neutral-700"
            >
              RESTART SECTOR [R]
            </button>
            <button
              type="button"
              onClick={onTitle}
              className="w-full py-2 bg-transparent hover:bg-neutral-900 text-neutral-400 hover:text-neutral-200 tracking-wider rounded-lg transition cursor-pointer"
            >
              ABORT TO MAIN MENU
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (state === 'victory') {
    const rankColors = {
      S: 'text-amber-400 border-amber-400 shadow-[0_0_16px_rgba(251,191,36,0.5)]',
      A: 'text-cyan-400 border-cyan-400 shadow-[0_0_16px_rgba(34,211,238,0.5)]',
      B: 'text-emerald-400 border-emerald-400 shadow-[0_0_16px_rgba(52,211,153,0.5)]',
      C: 'text-neutral-400 border-neutral-400 shadow-[0_0_16px_rgba(156,163,175,0.5)]',
    };

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 select-none">
        <div
          className="w-full max-w-lg border rounded-xl p-7 text-white shadow-2xl"
          style={{
            backgroundColor: `${currentTheme.navBg}fa`,
            borderColor: currentTheme.primaryAccent,
            boxShadow: `0 0 50px ${currentTheme.primaryAccent}44`,
          }}
        >
          <div
            className="flex items-center justify-between border-b pb-4 mb-5"
            style={{ borderColor: `${currentTheme.primaryAccent}33` }}
          >
            <div>
              <div
                className="font-mono text-xs tracking-[0.2em] font-bold uppercase"
                style={{ color: currentTheme.primaryAccent }}
              >
                EXTRACTION SUCCESSFUL
              </div>
              <h2 className="text-2xl font-mono font-black tracking-wide text-white">
                MISSION ACCOMPLISHED
              </h2>
            </div>
            {stats && (
              <div
                className={`w-14 h-14 rounded-full border-2 flex items-center justify-center font-mono text-2xl font-black ${
                  rankColors[stats.rank]
                }`}
              >
                {stats.rank}
              </div>
            )}
          </div>

          {stats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 font-mono">
              <div className="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800">
                <div className="text-[10px] text-neutral-400">CLEAR TIME</div>
                <div
                  className="text-lg font-bold tabular-nums"
                  style={{ color: currentTheme.primaryAccent }}
                >
                  {Math.floor(stats.clearTime / 60)}:
                  {(Math.floor(stats.clearTime % 60)).toString().padStart(2, '0')}
                </div>
              </div>
              <div className="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800">
                <div className="text-[10px] text-neutral-400">ALARMS</div>
                <div className="text-lg font-bold text-rose-400 tabular-nums">
                  {stats.alarmsTriggered}
                </div>
              </div>
              <div className="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800">
                <div className="text-[10px] text-neutral-400">DATACORES</div>
                <div
                  className="text-lg font-bold tabular-nums"
                  style={{ color: currentTheme.highlightAccent }}
                >
                  {stats.datacoresCollected}
                </div>
              </div>
              <div className="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800">
                <div className="text-[10px] text-neutral-400">SHIELDS</div>
                <div
                  className="text-lg font-bold tabular-nums"
                  style={{ color: currentTheme.primaryAccent }}
                >
                  {stats.shieldsRemaining} / 3
                </div>
              </div>
            </div>
          )}

          <div className="space-y-3 font-mono text-sm">
            {hasNextMission && onNextMission ? (
              <button
                type="button"
                data-start="true"
                onClick={onNextMission}
                className={`w-full py-3 font-bold tracking-widest rounded-lg transition cursor-pointer ${currentTheme.primaryBtn} ${currentTheme.primaryBtnHover} ${currentTheme.glowShadow}`}
              >
                PROCEED TO NEXT SECTOR [ENTER]
              </button>
            ) : null}
            <button
              type="button"
              onClick={onRestart}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 tracking-wider rounded-lg transition cursor-pointer border border-neutral-700"
            >
              REPLAY SECTOR [R]
            </button>
            <button
              type="button"
              onClick={onTitle}
              className="w-full py-2 bg-transparent hover:bg-neutral-900 text-neutral-400 hover:text-neutral-200 tracking-wider rounded-lg transition cursor-pointer"
            >
              RETURN TO TITLE
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Defeat / Game Over
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xs p-4 select-none">
      <div className="w-full max-w-md bg-[#12070a] border border-rose-500/50 rounded-xl p-6 shadow-[0_0_40px_rgba(244,63,94,0.3)] text-white text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <h2 className="font-mono text-xs tracking-[0.25em] text-rose-400 uppercase">
            SIGNAL TERMINATED // AGENT DOWN
          </h2>
        </div>
        <h3 className="text-2xl font-mono font-black tracking-wider text-rose-500 mb-2">
          MISSION FAILED
        </h3>
        <p className="text-xs text-neutral-400 mb-6 font-sans">
          The operative succumbed to facility security hazards. Regroup acoustic sync and attempt infiltration again.
        </p>

        {stats && (
          <div className="grid grid-cols-2 gap-3 mb-6 font-mono text-left">
            <div className="bg-neutral-950 p-2.5 rounded-lg border border-neutral-800">
              <div className="text-[10px] text-neutral-400">SURVIVAL TIME</div>
              <div className="text-base font-bold text-neutral-200 tabular-nums">
                {Math.floor(stats.clearTime)}s
              </div>
            </div>
            <div className="bg-neutral-950 p-2.5 rounded-lg border border-neutral-800">
              <div className="text-[10px] text-neutral-400">ALARMS SOUNDED</div>
              <div className="text-base font-bold text-rose-400 tabular-nums">
                {stats.alarmsTriggered}
              </div>
            </div>
          </div>
        )}

        <div className="space-y-3 font-mono text-sm">
          <button
            type="button"
            data-start="true"
            onClick={onRestart}
            className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold tracking-widest rounded-lg transition cursor-pointer shadow-[0_0_20px_rgba(244,63,94,0.4)]"
          >
            RETRY INFILTRATION [ENTER / R]
          </button>
          <button
            type="button"
            onClick={onTitle}
            className="w-full py-2 bg-transparent hover:bg-neutral-900 text-neutral-400 hover:text-neutral-200 tracking-wider rounded-lg transition cursor-pointer"
          >
            RETURN TO TITLE
          </button>
        </div>
      </div>
    </div>
  );
};
